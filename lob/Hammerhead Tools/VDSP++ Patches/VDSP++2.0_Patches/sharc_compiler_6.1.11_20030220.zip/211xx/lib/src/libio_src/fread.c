/************************************************************************
 *
 * fread.c
 *
 * (c) Copyright 2001 Analog Devices, Inc.  All rights reserved.
 *
 ************************************************************************/

#include "_stdio.h"

#include <stdio.h>
#include <string.h>

#include "adi_threads.h"

size_t
fread(void* bufptr, size_t size, size_t nelem, FILE* str)
{
  unsigned char* s = (unsigned char*) bufptr;
  size_t ns = (size * nelem) * BYTES_PER_WORD;  /* in bytes */
  size_t m, tmp;
  size_t n;

#if !defined(__ADSP21000__)
  unsigned int ltemp, *wrd, tmp2, tmp3;
#endif

  if (ns == 0)
    return 0;

  //in multithreaded programs, place lock to make operation atomic
  _PUSH_UNSCHEDULED_REGION();

  if (str->nback > 0)
  {
    /* If there are ungetc'd characters and there's room in the buffer,
       then restore the characters.  Anything that doesn't fit gets 
       flushed.  This may violate the guarantee that at least one
       ungetc must work. */

    while (str->nback > 0 && str->next > BYTE_ADDR(str->buf))
    {
      --str->next;
#if defined(__ADSP21000__)
      DEPOSIT_BYTE(*WORD_ADDR(str->next), str->next,
                         str->backbuf[--str->nback]);
#else 
      wrd = (unsigned int*)(str->next/2); 
      tmp3 = str->next * BITS_PER_BYTE;
      tmp3 = tmp3 % BITS_PER_WORD;
      ltemp = (1 << tmp3) - 1;
      tmp2 = (str->backbuf[--str->nback]) << BYTE_SHIFT(str->next);
      *wrd = (*wrd) & ltemp | tmp2;
#endif
    }

    str->rend = str->rsave;
  }

  /* Align as necessary.  This may lose some data, obviously. */
  if (str->next % BYTES_PER_WORD)
    str->next += BYTES_PER_WORD - str->next % BYTES_PER_WORD;

  while (ns > 0)
  {
    if (str->next >= str->rend)
      if (_fillreadbuf(str) <= 0)
        break;

    m = str->rend - str->next;                  /* data available (in bytes) */

    if (m > ns)
      m = ns;

    n = (m + (BYTES_PER_WORD - 1)) / BYTES_PER_WORD;

    memcpy(s,WORD_ADDR(str->next),n);

    str->next += m;
    ns -= m;
    s += n;
  }
  tmp = ((size * nelem) - (ns / BYTES_PER_WORD)) / size;

  _POP_UNSCHEDULED_REGION();
 
  return tmp;
}

// end of file
