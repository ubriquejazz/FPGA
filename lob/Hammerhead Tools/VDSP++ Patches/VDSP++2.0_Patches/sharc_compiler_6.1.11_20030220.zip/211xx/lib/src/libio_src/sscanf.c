/************************************************************************
 *
 * sscanf.c
 *
 * (c) Copyright 2001 Analog Devices, Inc.  All rights reserved.
 *
 ************************************************************************/

#include "_stdio.h"

#include "stdio.h"
#include "stdarg.h"

#include "adi_threads.h"

static int _thegetstringchar(int, void*);

int
sscanf(const char* buf, const char* fmt, ...)
{
    int ans;
    va_list ap;

  //in multithreaded programs, place lock to make operation atomic
  _PUSH_UNSCHEDULED_REGION();

    va_start(ap, fmt);
    ans = _doscan(fmt, ap, &_thegetstringchar, &buf);
    va_end(ap);

  _POP_UNSCHEDULED_REGION();

    return ans;
}

static int
_thegetstringchar(int ch, void* string)
{
    const char** s = (const char**) string;

    if (ch < 0)
    {
	if (**s == '\0')
	    return EOF;
	else
	    return *(*s)++;
    }
    else
	--(*s);

    return ch;
}

// end of file
