/*
** Copyright (C) 2001 Analog Devices, Inc. All Rights Reserved.
*/

#if defined(__ADSPTS__) || defined(__ADSP21000__) || defined(__ADSPBLACKFIN__)
#define LIB_VERSION "6.1.3"
#define LIBDSP_VERSION LIB_VERSION
#endif
