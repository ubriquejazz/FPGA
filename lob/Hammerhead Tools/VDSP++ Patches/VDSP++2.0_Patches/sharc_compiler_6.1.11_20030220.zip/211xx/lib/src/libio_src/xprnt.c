/************************************************************************
 *
 * xprnt.c
 *
 * (c) Copyright 2001 Analog Devices, Inc.  All rights reserved.
 *
 ************************************************************************/

#include "xprnt.h"

#include <string.h>

char _cvtbuf[MAXCVT+1] = {'\0'}; /* (initialising the array avoids
                                     weak symbols being generated) */

int _doprnt(const char* formatString, va_list args, FuncT func, FargT farg)
{
    const char*    cp = formatString;
    FormatT format = {NULL, 0,0,0,0,0, "", "", "",
            kNone, 0, false, false, false, false, false, false}; 
    int outsize=0;


    format.args = args;
    format.bZero = 0;

    while (*cp != '\0')
    {
    if (*cp != '%') {
        (*func)(farg, *cp++);
         outsize+=1;
    } else
    {
        cp = _parse_format(++cp, &format);

        switch (format.fcode)
        {
          case 'd':
          case 'u':
          case 'i':
        outsize+=_print_fixed(&format, 5, func, farg);
        break;
          case 'o':
        outsize+=_print_fixed(&format, 4, func, farg);
        break;
          case 'X':
          case 'x':
        outsize+=_print_fixed(&format, 8, func, farg);
        break;
          case 'E':
          case 'e':
        outsize+=_print_e_float(&format, func, farg, false);
        break;
          case 'f':
#if 0
        _print_f_float(&format, func, farg);
#else
        outsize+=_print_f_float2(&format, func, farg, false);
#endif
        break;
          case 'G':
          case 'g':
        outsize+=_print_g_float(&format, func, farg);
        break;

          case 'c':
        {
         char ch; ch = FETCH((&format), int);

            if ( format.width>0 ) {
                static char chbuf[2]={0,0};
                chbuf[0]=ch;
                format.buffer=chbuf;
                outsize+=_do_output(&format,func,farg);
            } else {
                (*func)(farg, ch);
                outsize+=1;
            }
        }
        break;

        case 'n':
        {
            void* ptr = FETCH((&format), void*);

            if ( format.bIsLong ) {
                *((long *) ptr) = outsize;
            } else {
                *((int *) ptr) = outsize;
            }
        }
        break;

        case 's':
        {
            char* s; s = FETCH((&format), char*);

            format.buffer=s;
            if ((format.width==0) && (format.precision<0)) {

                /*  Faster route for "%s"  */

                format.precision = strlen(s);
                _put_string( func,farg,s,format.precision );
                outsize+=format.precision;
            } else {

                /*  Standard route for "%[flags][width].[precision]s"  */

                outsize+=_do_output( &format,func,farg );
            }
        }
        break;

        case '\0':    /* Premature end of format string */
        cp--;
        break;
          default:    /* case '%': */
        (*func)(farg, format.fcode);
        outsize+=1;
        break;
        }
    }
    }
    return outsize;
}


// end of file
