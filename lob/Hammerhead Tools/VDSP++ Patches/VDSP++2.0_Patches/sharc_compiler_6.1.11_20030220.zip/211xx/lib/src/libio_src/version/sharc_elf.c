/*
** Copyright (C) 2001 Analog Devices, Inc. All Rights Reserved.
*/

#include "versions.h"
#define PREFIX "@(#) "

#ifdef LIBIO
const char *_epc_libio_version_number =
  PREFIX "libio " LIBIO_VERSION " (" __DATE__ " " __TIME__ ")\n" ;
#endif
