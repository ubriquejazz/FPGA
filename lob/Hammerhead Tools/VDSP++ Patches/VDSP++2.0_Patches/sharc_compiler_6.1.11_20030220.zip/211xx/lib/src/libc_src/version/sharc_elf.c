/*
** Copyright (C) 2001 Analog Devices, Inc. All Rights Reserved.
*/

#include "versions.h"
#define PREFIX "@(#) "

#ifdef LIBC
const char *_epc_libc_version_number =
  PREFIX "libc " LIBC_VERSION " (" __DATE__ " " __TIME__ ")\n" ;
#endif
