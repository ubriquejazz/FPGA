/************************************************************************
 *
 * xscan.c : $Revision: 1.2.2.5 $
 *
 * (c) Copyright 1998-2002 Analog Devices, Inc.  All rights reserved.
 *
 ************************************************************************/

#include "_stdio.h"

#include "stdio.h"
#include "limits.h"
#include "stdarg.h"
#include "string.h"
#include "ctype.h"
#include <stdlib.h>

typedef struct {
    va_list             args;
    ScanFnT             getfn;
    ScanContextT        context;

    const char*         fmt;

    int                 nread;

    int                 assign;
    int                 width;
    char                mod;
    char                spec;
}       ScanConversionT;

#define FMAX            100     /* Widest supported number field */

/* Macro City */

// Fetches an argument of type TYP from the argument array held in
// CVT (of type ScanConversionT *) 
#define FETCH_ARG(LHS,CVT, TYP)     \
    do {(LHS) = *(TYP*) (CVT)->args; (CVT)->args += sizeof(TYP);} while (0)

// Assigns the scanned value (VAL) through an argument pointer
#define ASSIGN_ARG(CVT, TYP, VAL)       \
    **(TYP*) (CVT)->args = (VAL);       \
    (CVT)->args += sizeof(TYP)

// These are the basic get character and unget character macros. 
#define GET1(CVT)       ((CVT)->nread++,(CVT)->getfn(DO_GETC, (CVT)->context))
#define UNGET1(CH, CVT) ((CVT)->nread--,(CVT)->getfn(CH, (CVT)->context))

// Tests whether there are NREAD0 more characters available from this
// width-limited field. 
#define TOO_MANY(CVT, NREAD0) ((CVT)->nread - (NREAD0) >= (CVT)->width)

// Width-limited versions of get character and unget character 
#define GET1W(CVT, NREAD0) (TOO_MANY(CVT, NREAD0) ? EOF : GET1(CVT))
#define UNGET1W(CH, CVT) ((CH) >= 0 ? UNGET1(CH, CVT) : 0)

#define S_CONSUME(NXT) do { *p++ = ch; state = NXT; } while (0)
#define S_EPSILON(NXT) do { UNGET1W(ch, cvt); state = NXT; } while (0)
#define S_ERROR      do { UNGET1W(ch, cvt); state = ERROR; } while (0)
#define S_ACCEPT     do { UNGET1W(ch, cvt); state = ACCEPT; } while (0)

/*

   >[ S1 ] --- +- ---> [ S2 ] --- 0 ---> [[ S3 ]] --- xX ---> [ S4 ]-\
       \                  > \              \                         |
        ------ e --------/   \              \                        |
                              e               e          digit     digit
                               \               \          |  |       |
                                \               \----->   \  v       |
                                 \--------------------> [[ S5 ]] <-- /



*/


// Returns 1 (success), 0 (failure), or EOF 
static int
scanInt(ScanConversionT* cvt)
{
    char buf[FMAX+1];
    char* p = buf;
    static const char digits[] =
        "0123456789ABCDEFabcdef";
    int ndigits;
    int base = cvt->spec == 'd' || cvt->spec == 'u'     ? 10 :
               cvt->spec == 'i'                         ? 0  :
               cvt->spec == 'o'                         ? 8  :
                 /* 'x', 'X', 'p' */                      16;

    int nread0 = cvt->nread;
    int ch;
    enum {S1, S2, S3, S4, S5, ACCEPT, ERROR} state = S1;

    ndigits = base == 0 || base == 10 ? 10 :
              base == 8               ? 8  :
                                      22;  /* 10 digits + 12 hex */
    if (cvt->width <= 0)
        cvt->width = FMAX;

    while (state != ERROR && state != ACCEPT)
    {
        ch = GET1W(cvt, nread0);

        switch (state)
        {
          case S1:
            if (ch == '+' || ch == '-') S_CONSUME(S2);
            else                        S_EPSILON(S2);
            break;

          case S2:
            if (ch == '0') S_CONSUME(S3);
            else           S_EPSILON(S5);
            break;

          case S3:
            if ((ch == 'x' || ch == 'X') && (base == 0 || base == 16))
                { base = 16; ndigits = 22; S_CONSUME(S4); }
            else { if (base == 0) base = ndigits = 8; S_EPSILON(S5); }
            break;

          case S4:
            if (memchr(digits, ch, ndigits)) S_CONSUME(S5);
            else                             S_ERROR;
            break;

          case S5:
            if (memchr(digits, ch, ndigits)) S_CONSUME(S5);
            else                             S_ACCEPT;
            break;
        }
    }

    *p = '\0';

    if (state != ACCEPT || p == buf)    // State machine accepts empty strings,
                                        // so, we reject them explicitly here.
        return ch == EOF ? EOF : 0; 

    if (cvt->assign)
    {
        if (cvt->spec == 'd' || cvt->spec == 'i')
        {
            long l = strtol(buf, (char **)NULL, base);

            if (cvt->mod == 'h') { ASSIGN_ARG(cvt, short *, l); }
            else if (cvt->mod == 'l') { ASSIGN_ARG(cvt, long *, l); }
            else { ASSIGN_ARG(cvt, int *, l); }
        }
        else
        {
            unsigned long ul = strtoul(buf, (char **)NULL, base);

            if (cvt->spec == 'p')
            {

#if defined(__ADSP21XX__)
                if (cvt->mod == 'l')
                {
                    ASSIGN_ARG(cvt, void (**)(void)), (void (*)(void)) ul);
                } else {
                    ASSIGN_ARG(cvt, void**, (void*) ul);
                }
#else
                ASSIGN_ARG(cvt, void**, (void*) ul);
#endif
            } else if (cvt->mod == 'h') {
                ASSIGN_ARG(cvt, unsigned short *, ul);
            } else if (cvt->mod == 'l') {
                ASSIGN_ARG(cvt, unsigned long *, ul);
            } else {
                ASSIGN_ARG(cvt, unsigned int *, ul);
            }
        }
    }

    return 1;
}


static int
scanFloat(ScanConversionT* cvt)
{
    char buf[FMAX+1];
    char* p = buf;

    int nread0 = cvt->nread;
    int ch;
    enum {S1, S2, S3, S4, S5, S6, S7, ACCEPT, ERROR} state = S1;

    if (cvt->width <= 0)
        cvt->width = FMAX;

    while (state != ERROR && state != ACCEPT)
    {
        ch = GET1W(cvt, nread0);

        switch (state)
        {
          case S1:
            if (ch == '+' || ch == '-') S_CONSUME(S2);
            else                        S_EPSILON(S2);
            break;

          case S2:
            if (isdigit(ch))    S_CONSUME(S3);
            else if (ch == '.') S_CONSUME(S4);
            else                S_ERROR;
            break;

          case S3:
            if (isdigit(ch))    S_CONSUME(S3);
            else if (ch == '.') S_CONSUME(S4);
            else if (ch == 'e' || ch == 'E') S_CONSUME(S5);
            else                S_ACCEPT;
            break;

          case S4:
            if (isdigit(ch)) S_CONSUME(S4);
            else if (ch == 'e' || ch == 'E') S_CONSUME(S5);
            else                S_ACCEPT;
            break;

          case S5:
            if (ch == '+' || ch == '-') S_CONSUME(S6);
            else                        S_EPSILON(S6);
            break;

          case S6:
            if (isdigit(ch)) S_CONSUME(S7);
            else             S_ERROR;
            break;

          case S7:
            if (isdigit(ch)) S_CONSUME(S7);
            else             S_ACCEPT;
            break;
        }
    }

    *p = '\0';

    if (state != ACCEPT)
        return ch == EOF ? EOF : 0;

    if (cvt->assign)
    {
        double d = strtod(buf, (char **)NULL);

        if (cvt->mod == 'l') { ASSIGN_ARG(cvt, double *, d); }
        else if (cvt->mod == 'L') { ASSIGN_ARG(cvt, long double *, d); }
        else { ASSIGN_ARG(cvt, float *, d); }
    }

    return 1;
}

static int     /* Returns true if the field scanned correctly */
_scan1(ScanConversionT* cvt)
{
    int     ch;

    if (!strchr((const char *)"cn[", (int)(cvt->spec)))
    {
        while (isspace(ch = GET1(cvt)))
            ;
        UNGET1(ch, cvt);
    }

    switch (cvt->spec)
    {
      case 'c':
        {
            char* p;

            if (cvt->assign)
                FETCH_ARG(p,cvt, char*);

            if (cvt->width == 0)
                cvt->width = 1;
            for (; cvt->width > 0; --cvt->width)
            {
                if ((ch = GET1(cvt)) < 0)
                    return EOF;
                else if (cvt->assign)
                    *p++ = ch;
            }
        }
        return 1;

      case '%':
        if ((ch = GET1(cvt)) == '%')
            return 1;
        UNGET1(ch, cvt);
        return 0;

      case 'p': case 'd': case 'i':
      case 'o': case 'u': case 'x': case 'X':
        return scanInt(cvt);

      case 'e': case 'E': case 'f': case 'g': case 'G':
        return scanFloat(cvt);

      case 'n':
        if (cvt->assign)
        {
            if (cvt->mod == 'h')
            {   ASSIGN_ARG(cvt, short *, cvt->nread); }
            else if (cvt->mod == 'l')
            {   ASSIGN_ARG(cvt, long *, cvt->nread);  }
            else
            {   ASSIGN_ARG(cvt, int *, cvt->nread);   }
        }
        return 1;

      case 's':
        {
            int nread0 = cvt->nread;
            char* p;
            if (cvt->assign)
                FETCH_ARG(p,cvt, char *);

            if (cvt->width <= 0)
                cvt->width = INT_MAX;

            while (!TOO_MANY(cvt, nread0))
            {
                if ((ch = GET1(cvt)) < 0)
                    break;
                else if (isspace(ch))
                {
                    UNGET1(ch, cvt);
                    break;
                }
                else if (cvt->assign)
                    *p++ = ch;
            }

            if (cvt->assign)
                *p = '\0';

            if (ch < 0)
                return 0;
        }
        return 1;

      case '[':
        {
            int nread0 = cvt->nread;
            int compl = *cvt->fmt == '^';
            const char *stop;             /* ptr to matching ']'             */
            const char *start;            /* temporary pointer into scanlist */
            size_t setn;                  /* length of scanlist              */
            char* p;

            if (cvt->assign)
                FETCH_ARG(p,cvt, char *);

            if (compl)
                cvt->fmt++;

            start = cvt->fmt;
            if (*start == ']')
                start++;
            stop = strchr(start,']');
            if (stop == NULL)
                return 0;
            setn = stop - cvt->fmt;

            if (cvt->width <= 0)
                cvt->width = INT_MAX;

            while (!TOO_MANY(cvt, nread0))
            {
                if ((ch = GET1(cvt)) < 0)
                    break;
                else if (compl ? memchr(cvt->fmt, ch, setn) != NULL
                               : memchr(cvt->fmt, ch, setn) == NULL)
                {
                    UNGET1(ch, cvt);
                    break;
                }
                else if (cvt->assign)
                    *p++ = ch;
            }

            if (cvt->assign)
                *p = '\0';

            cvt->fmt = stop + 1;
        }
        return 1;

      default:
        return 0;
    }
}

int
_doscan(const char* fmtString, va_list args, ScanFnT getfn, ScanContextT context)
{
    const char* cp = fmtString;
    int         ch;
    int nconversions = 0;
    ScanConversionT cvt;


    cvt.args = args;
    cvt.getfn = getfn;
    cvt.context = context;
    cvt.nread = 0;

    while (*cp != '\0')
    {
        if (*cp == '%')
        {
            cp++;
            cvt.assign = *cp != '*' ? 1 : (cp++, 0);
            cvt.width = 0;
            for (; isdigit(*cp); cp++)
                cvt.width = cvt.width * 10 + (*cp - '0');
            cvt.mod = strchr("hlL", *cp) ? *cp++ : 0;
            cvt.spec = *cp++;
            
            cvt.fmt = cp;

            if ((ch = _scan1(&cvt)) > 0) 
            {
                cp = cvt.fmt;

                if (cvt.assign)
                    nconversions++;
            }
            else if (ch < 0 && nconversions == 0)
                                return EOF; 
            else
            {
                if (cvt.assign)
                   nconversions++;
                return nconversions;
            }
        }
        else if (isspace(*cp))
        {
            while (isspace(*cp))
                cp++;
            while (isspace(ch = GET1(&cvt)))
                ;
            UNGET1(ch, &cvt);
        }
        else if ((ch = GET1(&cvt)) != *cp++)
        {
            UNGET1(ch, &cvt);
            return nconversions;
        }
        /* else a literal match succeeded */
    }

    return nconversions;
            
}

// end of file
