/*
** Copyright (C) 2001 Analog Devices, Inc. All Rights Reserved.
*/

#include "versions.h"
#define PREFIX "@(#) "

#ifdef LIBDSP
const char *_epc_libdsp_version_number =
  PREFIX "libdsp " LIBDSP_VERSION " (" __DATE__ " " __TIME__ ")\n" ;
#endif
