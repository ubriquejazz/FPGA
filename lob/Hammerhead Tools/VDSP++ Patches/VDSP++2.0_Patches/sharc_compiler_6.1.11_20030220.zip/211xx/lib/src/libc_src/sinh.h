/* This include file is used for the hyperbolic sine
   and hyperbolic cosine */

#define eps 0.000244140625

#define p0 -0.713793159E+1
#define p1 -0.190333399
#define q0 -0.428277109E+2

#define ybar 85.0

#define ln_v 0.69316101074218750000
#define v_raised_minus_2 0.24999308500451499336
#define v_over_2_minus_1 0.13830277879601902638E-4

#define wmax 88.7
