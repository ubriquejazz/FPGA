/************************************************************************
 *
 * sysreg.h
 *
 * (c) Copyright 1998-2001 Analog Devices, Inc.  All rights reserved.
 *
 ************************************************************************/

/*************************************
SHARC System Register Access Functions

The SHARC has a number of "system registers".  This header defines a set
of built-in functions which can be used to access these registers from
compiled code, in a clean, efficient manner.

The SHARC architecture provides for up to 16 system registers.  See the
user's manual for the specific processors for a list of the registers
and their definition.  For the 2106x processors, there is a chart on
page A-12 of the User's Manual (edition 1).


 Symbolic constants are provided for referring to the registers
themselves.  These values are not necessarily those used by the
hardware; please refer to the definitions given in this file.
 NOTE that The register and bit numbers MUST be constants, not
calculated values.  This is a hardware restriction.  A error message
will be given.


 Headers such as <def21060.h> are available, which contain
descriptions and bit definitions for many registers including the system
control registers.


The functions provided here are based on the underlying hardware
capabilities.  They allow direct read and write access, as well as
testing and modifying sets of bits.

Notes for SHARC  (2106x):
 - there is a latency of 2 cycles before changes to IMASKP take effect.
To guarantee correct behavior, the compiler will emit a "nop" after a
sysreg operation involving IMASKP.
 - The compiler considers USTAT1 and USTAT2 to be "preserved"
registers.  If one is modified by a sysreg operation, it will be saved
during the prolog of the containing function, and restored to its old
value on exit.


*************************************/

#ifndef __SYSREG_DEFINED
#define __SYSREG_DEFINED

#if defined(__cplusplus) 
extern "C" {
#endif

	// read designated register, return value

unsigned int __builtin_sysreg_read (const int SR_number);

	// write designated register; no value

void __builtin_sysreg_write (const int SR_number, const unsigned int new_value);

	//set or clear or toggle a [set of] bits

void __builtin_sysreg_bit_clr(const int SR_number, const unsigned int bit_mask);
void __builtin_sysreg_bit_set(const int SR_number, const unsigned int bit_mask);
void __builtin_sysreg_bit_tgl(const int SR_number, const unsigned int bit_mask);


	// Provide versions of the sysreg modify functions which 
	// place a 'nop' after the instruction.

void __builtin_sysreg_write_nop (const int SR_number, const unsigned int new_value);
void __builtin_sysreg_bit_clr_nop(const int SR_number, const unsigned int bit_mask);
void __builtin_sysreg_bit_set_nop(const int SR_number, const unsigned int bit_mask);
void __builtin_sysreg_bit_tgl_nop(const int SR_number, const unsigned int bit_mask);


	// test if specified bits are all '1'

int __builtin_sysreg_bit_tst(const int SR_number, const unsigned int bit_mask);

	 // test if sysreg contents are equal to given value

int __builtin_sysreg_bit_tst_all(const int SR_number, const unsigned int value);

#if defined(__cplusplus) 
}
#endif


// provide define's for  Simpler Names 

#define sysreg_read(r)            __builtin_sysreg_read(r)

#define sysreg_write(r, val)      __builtin_sysreg_write(r, val)
#define sysreg_write_nop(r, val)  __builtin_sysreg_write_nop(r, val)


#define sysreg_bit_clr(r, bits)       __builtin_sysreg_bit_clr(r, bits)
#define sysreg_bit_set(r, bits)       __builtin_sysreg_bit_set(r, bits)
#define sysreg_bit_tgl(r, bits)       __builtin_sysreg_bit_tgl(r, bits)  
#define sysreg_bit_clr_nop(r, bits)   __builtin_sysreg_bit_clr_nop(r, bits)
#define sysreg_bit_set_nop(r, bits)   __builtin_sysreg_bit_set_nop(r, bits)
#define sysreg_bit_tgl_nop(r, bits)   __builtin_sysreg_bit_tgl_nop(r, bits)  


	// test if bits are set... some or all

#define sysreg_bit_tst(r, bits)    __builtin_sysreg_bit_tst(r, bits)   
#define sysreg_tst(r, bits)        __builtin_sysreg_bit_tst_all(r, bits)



/* *****************************************************
   Symbolic names for the system registers.

(for current compiler  990915)

*/
enum SysReg {
  sysreg_MODE1,
  sysreg_MODE2,
  sysreg_IRPTL,
  sysreg_IMASK,
  sysreg_IMASKP,
  sysreg_ASTAT,
  sysreg_STKY,
  sysreg_USTAT1,
  sysreg_USTAT2,

#ifdef __2116x__
  sysreg_LIRPTL,
  sysreg_MMASK,
  sysreg_ASTATY,
  sysreg_FLAGS,
  sysreg_STKYY,
  sysreg_USTAT3,
  sysreg_USTAT4,
#endif
   sysreg_END
};	


/*
* Numerical values are from the Universal Register Codes map,
* (see Appendix A of SHARC User's Manual, page A-12 of edition 1) 
* .. these are the last four bits of the register number, which
* is what actually is used in the bit instructions.
*
enum SysReg {
  sysreg_USTAT1 = 0,
  sysreg_USTAT2 = 1,
	// values 2 thru 8 are invalid for 2106x
  sysreg_IRPTL = 0x9,
  sysreg_MODE2 = 0xa,
  sysreg_MODE1 = 0xb,
  sysreg_ASTAT = 0xc,
  sysreg_IMASK = 0xd,
  sysreg_STKY  = 0xe,
  sysreg_IMASKP= 0xf
};	
************/

#endif /* __SYSREG_DEFINED */
