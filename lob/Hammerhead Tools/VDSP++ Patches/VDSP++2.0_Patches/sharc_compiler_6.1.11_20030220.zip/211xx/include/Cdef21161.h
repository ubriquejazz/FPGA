/************************************************************************
 *
 * Cdef21161.h
 *
 * (c) Copyright 2001 Analog Devices, Inc.  All rights reserved.
 *
 ************************************************************************/

/* ----------------------------------------------------------------------------

Cdef21161.h - SYSTEM & IOP REGISTER BIT & ADDRESS DEFINITIONS FOR ADSP-21161
Last updated 5/14/01

This include file contains macros definitions of the IOP registers which
allow them to be used in C or C++ programs. Each macro is similar to that
in def21161.h, except that the macro is prefixed with 'p' and the relevant
casts are include in the macro definition. They can be used as follows:

   *pSYSTAT = 0x12345678;  // Set the SYSTAT register

----------------------------------------------------------------------------- */
#ifndef __CDEF21161_H_
#define __CDEF21161_H_ 

/*------------------------------------------------------------------------------*/
/*                                                                              */
/*                 I/O Processor Register Address Memory Map                    */
/*                                                                              */
/*------------------------------------------------------------------------------*/
#define pSYSCON ((volatile unsigned int *) 0x00)        	/* System configuration register                    */
#define pVIRPT  ((volatile unsigned int *) 0x01)        	/* Vector interrupt register                        */
#define pWAIT   ((volatile unsigned int *) 0x02)        	/* External Port Wait register - renamed to EPCON   */
#define pEPCON  ((volatile unsigned int *) 0x02)        	/* External Port configuration register             */
#define pSYSTAT ((volatile unsigned int *) 0x03)        	/* System status register                           */
/* the upper 32-bits of the 64-bit epbxs are only accessible as 64-bit reference*/
#define pEPB0   ((volatile unsigned int *) 0x04)        	/* External port DMA buffer 0                       */
#define pEPB1   ((volatile unsigned int *) 0x06)        	/* External port DMA buffer 1                       */
#define pMSGR0  ((volatile unsigned int *) 0x08)        	/* Message register 0                               */
#define pMSGR1  ((volatile unsigned int *) 0x09)        	/* Message register 1                               */
#define pMSGR2  ((volatile unsigned int *) 0x0a)        	/* Message register 2                               */
#define pMSGR3  ((volatile unsigned int *) 0x0b)        	/* Message register 3                               */
#define pMSGR4  ((volatile unsigned int *) 0x0c)        	/* Message register 4                               */
#define pMSGR5  ((volatile unsigned int *) 0x0d)        	/* Message register 5                               */
#define pMSGR6  ((volatile unsigned int *) 0x0e)        	/* Message register 6                               */
#define pMSGR7  ((volatile unsigned int *) 0x0f)        	/* Message register 7                               */

/* IOP shadow registers of the core control regs                                */
#define pPC_SHDW    ((volatile unsigned int *) 0x10)	   	/* PC IOP shadow register (PC[23-0])                */
#define pMODE2_SHDW ((volatile unsigned int *) 0x11)	   	/* Mode2 IOP shadow register (MODE2[31-25])         */
#define pEPB2   ((volatile unsigned int *) 0x14)        	/* External port DMA buffer 2                       */
#define pEPB3   ((volatile unsigned int *) 0x16)        	/* External port DMA buffer 3                      	*/
#define pBMAX   ((volatile unsigned int *) 0x18)	       	/* Bus time-out maximum			      			   	*/
#define pBCNT   ((volatile unsigned int *) 0x19)	       	/* Bus time-out counter			      			   	*/  		
#define pDMAC10 ((volatile unsigned int *) 0x1c)	   		/* EP DMA10 control register			      		*/
#define pDMAC11 ((volatile unsigned int *) 0x1d)	   		/* EP DMA11 control register			      		*/
#define pDMAC12 ((volatile unsigned int *) 0x1e)	   		/* EP DMA12 control register			      		*/
#define pDMAC13 ((volatile unsigned int *) 0x1f)	   		/* EP DMA13 control register			      		*/
#define pDMASTAT ((volatile unsigned int *) 0x37)	    /* DMA channel status register		      			*/

/* SPI Registers  IOP Register Addresses*/
#define pSPICTL    ((volatile unsigned int *) 0xb4)		/* Serial peripheral-compatible interface control register */
#define pSPISTAT   ((volatile unsigned int *) 0xb5)		/* Serial periipheral-compatible interface status register */
#define pSPIRX     ((volatile unsigned int *) 0xb7)		/* SPI receive data buffer */
#define pSPITX     ((volatile unsigned int *) 0xb6)		/* SPI transmit data buffer */

/* IOFLAG Register Address */
#define pIOFLAG	  ((volatile unsigned int *) 0x1b)		/* Address of programmable I/O flags 4-11 */

/* IOP registers for SDRAM controller.     */
#define pSDCTL    ((volatile unsigned int *) 0xb8)      	/* SDRAM control reg.            					*/
#define pSDRDIV   ((volatile unsigned int *) 0xb9)      	/* Refresh counter div reg.      					*/

/* Link Port Registers */
#define pLBUF0  	((volatile unsigned int *) 0xc0)	   	/* Link buffer 0				 					*/
#define pLBUF1  	((volatile unsigned int *) 0xc2)	   	/* Link buffer 1				 					*/
#define pLCTL   	((volatile unsigned int *) 0xcc)	   	/* Link buffer control			 					*/
#define pLSRQ   	((volatile unsigned int *) 0xd0)	   	/* Link service request and mask registers  		*/

/* SPORT0 */
#define pSPCTL0	((volatile unsigned int *) 0x1c0)      	/* SPORT0 serial port control register 					*/ 
#define pTX0A   	((volatile unsigned int *) 0x1c1)		/* SPORT0 serial port control register 					*/ 
#define pTX0B   	((volatile unsigned int *) 0x1c2)  		/* SPORT0 transmit secondary B channel data buffer 		*/
#define pRX0A   	((volatile unsigned int *) 0x1c3)  		/* SPORT0 receive primary A channel data buffer 		*/
#define pRX0B   	((volatile unsigned int *) 0x1c4)  		/* SPORT0 receive secondary B channel data buffer 		*/
#define pDIV0 	((volatile unsigned int *) 0x1c5) 		/* SPORT0 divisor for transmit/receive SLCK0 and FS0 	*/
#define pCNT0 	((volatile unsigned int *) 0x1c6)       /* SPORT0 count register 								*/

/* SPORT2 */
#define pSPCTL2	((volatile unsigned int *) 0x1d0)       /* SPORT2 serial port control register 					*/ 
#define pTX2A   	((volatile unsigned int *) 0x1d1)   	/* SPORT2 serial port control register 					*/ 
#define pTX2B   	((volatile unsigned int *) 0x1d2)  		/* SPORT2 transmit secondary B channel data buffer 		*/
#define pRX2A   	((volatile unsigned int *) 0x1d3)  		/* SPORT2 receive primary A channel data buffer 		*/
#define pRX2B   	((volatile unsigned int *) 0x1d4)  		/* SPORT2 receive secondary B channel data buffer 		*/
#define pDIV2 	((volatile unsigned int *) 0x1d5) 		/* SPORT2 divisor for transmit/receive SLCK2 and FS2 	*/
#define pCNT2 	((volatile unsigned int *) 0x1d6)       /* SPORT2 count register 								*/

/* SPORT1 */   
#define pSPCTL1	((volatile unsigned int *) 0x1e0)       /* SPORT1 serial port control register 					*/ 
#define pTX1A   	((volatile unsigned int *) 0x1e1)   	/* SPORT1 serial port control register 					*/
#define pTX1B   	((volatile unsigned int *) 0x1e2)  		/* SPORT1 transmit secondary B channel data buffer 		*/
#define pRX1A   	((volatile unsigned int *) 0x1e3)  		/* SPORT1 receive primary A channel data buffer 		*/
#define pRX1B   	((volatile unsigned int *) 0x1e4)  		/* SPORT1 receive secondary B channel data buffer 		*/
#define pDIV1 	((volatile unsigned int *) 0x1e5) 		/* SPORT1 divisor for transmit/receive SLCK1 and FS1 	*/
#define pCNT1 	((volatile unsigned int *) 0x1e6)       /* SPORT1 count register 								*/

/* SPORT3 */   
#define pSPCTL3	((volatile unsigned int *) 0x1f0)       /* SPORT3 serial port control register 					*/ 
#define pTX3A   	((volatile unsigned int *) 0x1f1)   	/* SPORT3 serial port control register 					*/
#define pTX3B   	((volatile unsigned int *) 0x1f2)  		/* SPORT3 transmit secondary B channel data buffer 		*/
#define pRX3A   	((volatile unsigned int *) 0x1f3)  		/* SPORT3 receive primary A channel data buffer 		*/
#define pRX3B   	((volatile unsigned int *) 0x1f4)  		/* SPORT3 receive secondary B channel data buffer 		*/
#define pDIV3 	((volatile unsigned int *) 0x1f5) 		/* SPORT3 divisor for transmit/receive SLCK3 and FS3 	*/
#define pCNT3 	((volatile unsigned int *) 0x1f6)       /* SPORT3 count register 								*/

/* SPORT0 - MCM Receive (Works in pair with SPORT2) */
#define pMR0CS0		((volatile unsigned int *) 0x1c7) 	/* SPORT0 multichannel rx select, channels 31 - 0 			*/
#define pMR0CCS0 	((volatile unsigned int *) 0x1c8) 	/* SPORT0 multichannel rx compand select, channels 31 - 0 	*/
#define pMR0CS1      ((volatile unsigned int *) 0x1c9) 	/* SPORT0 multichannel rx select, channels 63 - 32 			*/
#define pMR0CCS1     ((volatile unsigned int *) 0x1ca) 	/* SPORT0 multichannel rx compand select, channels 63 - 32 	*/
#define pMR0CS2      ((volatile unsigned int *) 0x1cb) 	/* SPORT0 multichannel rx select, channels 95 - 64 			*/
#define pMR0CCS2     ((volatile unsigned int *) 0x1cc) 	/* SPORT0 multichannel rx compand select, channels 95 - 64 	*/
#define pMR0CS3      ((volatile unsigned int *) 0x1cd) 	/* SPORT0 multichannel rx select, channels 127 - 96 		*/
#define pMR0CCS3     ((volatile unsigned int *) 0x1ce)	/* SPORT0 multichannel rx compand select, channels 127 - 96 */

/* SPORT2 - MCM Transmit (Works in pair with SPORT0) */
#define pMT2CS0      ((volatile unsigned int *) 0x1d7) 	/* SPORT2 multichannel tx select, channels 31 - 0 			*/
#define pMT2CCS0     ((volatile unsigned int *) 0x1d8) 	/* SPORT2 multichannel tx compand select, channels 31 - 0 	*/
#define pMT2CS1      ((volatile unsigned int *) 0x1d9) 	/* SPORT2 multichannel tx select, channels 63 - 32 			*/
#define pMT2CCS1     ((volatile unsigned int *) 0x1da) 	/* SPORT2 multichannel tx compand select, channels 63 - 32 	*/
#define pMT2CS2      ((volatile unsigned int *) 0x1db) 	/* SPORT2 multichannel tx select, channels 95 - 64 			*/
#define pMT2CCS2     ((volatile unsigned int *) 0x1dc) 	/* SPORT2 multichannel tx compand select, channels 95 - 64 	*/
#define pMT2CS3      ((volatile unsigned int *) 0x1dd) 	/* SPORT2 multichannel tx select, channels 127 - 96 		*/
#define pMT2CCS3     ((volatile unsigned int *) 0x1de) 	/* SPORT2 multichannel tx compand select, channels 127 - 96 */

#define pSP02MCTL    ((volatile unsigned int *) 0x1df) 	/* SPORTs 0 & 2 Multichannel Control Register */

/* SPORT1 - MCM Receive (Works in pair with SPORT3) */
#define pMR1CS0      ((volatile unsigned int *) 0x1e7) 	/* SPORT1 multichannel rx select, channels 31 - 0 			*/
#define pMR1CCS0     ((volatile unsigned int *) 0x1e8) 	/* SPORT1 multichannel rx compand select, channels 31 - 0 	*/
#define pMR1CS1      ((volatile unsigned int *) 0x1e9) 	/* SPORT1 multichannel rx select, channels 63 - 32 			*/
#define pMR1CCS1     ((volatile unsigned int *) 0x1ea) 	/* SPORT1 multichannel rx compand select, channels 63 - 32 	*/
#define pMR1CS2      ((volatile unsigned int *) 0x1eb) 	/* SPORT1 multichannel rx select, channels 95 - 64 			*/
#define pMR1CCS2     ((volatile unsigned int *) 0x1ec) 	/* SPORT1 multichannel rx compand select, channels 95 - 64 	*/
#define pMR1CS3      ((volatile unsigned int *) 0x1ed) 	/* SPORT1 multichannel rx select, channels 127 - 96 		*/
#define pMR1CCS3     ((volatile unsigned int *) 0x1ee)	/* SPORT1 multichannel rx compand select, channels 127 - 96 */

/* SPORT3 - MCM Transmit (Works in pair with SPORT1) */
#define pMT3CS0      ((volatile unsigned int *) 0x1f7) 	/* SPORT3 multichannel tx select, channels 31 - 0 			*/
#define pMT3CCS0     ((volatile unsigned int *) 0x1f8) 	/* SPORT3 multichannel tx compand select, channels 31 - 0 	*/
#define pMT3CS1      ((volatile unsigned int *) 0x1f9) 	/* SPORT3 multichannel tx select, channels 63 - 32 			*/
#define pMT3CCS1     ((volatile unsigned int *) 0x1fa) 	/* SPORT3 multichannel tx compand select, channels 63 - 32 	*/
#define pMT3CS2      ((volatile unsigned int *) 0x1fb) 	/* SPORT3 multichannel tx select, channels 95 - 64 			*/
#define pMT3CCS2     ((volatile unsigned int *) 0x1fc) 	/* SPORT3 multichannel tx compand select, channels 95 - 64 	*/
#define pMT3CS3      ((volatile unsigned int *) 0x1fd) 	/* SPORT3 multichannel tx select, channels 127 - 96 		*/
#define pMT3CCS3     ((volatile unsigned int *) 0x1fe) 	/* SPORT3 multichannel tx compand select, channels 127 - 96 */

#define pSP13MCTL    ((volatile unsigned int *) 0x1ff)	/* SPORTs 1 & 3 Multichannel Control Register */


/*------ DMA Parameter Register Assignments - New Naming Conventions -------*/

/* DMA Channel 0 - Serial Port 0, A channel data */
#define pII0A    ((volatile unsigned int *) 0x60)	   /* Internal DMA0 memory address		      		*/
#define pIM0A    ((volatile unsigned int *) 0x61)	   /* Internal DMA0 memory access modifier	      	*/
#define pC0A     ((volatile unsigned int *) 0x62)	   /* Contains number of DMA0 transfers remaining   */
#define pCP0A    ((volatile unsigned int *) 0x63)	   /* Points to next DMA0 parameters		      	*/
#define pGP0A    ((volatile unsigned int *) 0x64)	   /* DMA0 General purpose		      				*/

/* DMA Channel 1 - Serial Port 0, B channel data */
#define pII0B    ((volatile unsigned int *) 0x80)	   /* Internal DMA1 memory address		      		*/
#define pIM0B    ((volatile unsigned int *) 0x81)	   /* Internal DMA1 memory access modifier	      	*/
#define pC0B     ((volatile unsigned int *) 0x82)	   /* Contains number of DMA1 transfers remaining   */
#define pCP0B    ((volatile unsigned int *) 0x83)	   /* Points to next DMA1 parameters		      	*/
#define pGP0B    ((volatile unsigned int *) 0x84)	   /* DMA1 General purpose		      				*/

/* DMA Channel 2 - Serial Port 1, A channel data */
#define pII1A    ((volatile unsigned int *) 0x68)	   /* Internal DMA2 memory address		      		*/
#define pIM1A    ((volatile unsigned int *) 0x69)	   /* Internal DMA2 memory access modifier	      	*/
#define pC1A     ((volatile unsigned int *) 0x6a)	   /* Contains number of DMA2 transfers remaining   */
#define pCP1A    ((volatile unsigned int *) 0x6b)	   /* Points to next DMA2 parameters		      	*/
#define pGP1A    ((volatile unsigned int *) 0x6c)	   /* DMA2 General purpose 		      				*/

/* DMA Channel 3 - Serial Port 1, B channel data */
#define pII1B    ((volatile unsigned int *) 0x88)	   /* Internal DMA3 memory address		      		*/
#define pIM1B    ((volatile unsigned int *) 0x89)	   /* Internal DMA3 memory access modifier	      	*/
#define pC1B     ((volatile unsigned int *) 0x8a)	   /* Contains number of DMA3 transfers remaining   */
#define pCP1B    ((volatile unsigned int *) 0x8b)	   /* Points to next DMA3 parameters		      	*/
#define pGP1B    ((volatile unsigned int *) 0x8c)	   /* DMA3 General purpose		      				*/

/* DMA Channel 4 - Serial Port 2, A channel data 							*/
#define pII2A    ((volatile unsigned int *) 0x70)	   /* Internal DMA4 memory address		      		*/
#define pIM2A    ((volatile unsigned int *) 0x71)	   /* Internal DMA4 memory access modifier	      	*/
#define pC2A     ((volatile unsigned int *) 0x72)	   /* Contains number of DMA4 transfers remaining   */
#define pCP2A    ((volatile unsigned int *) 0x73)	   /* Points to next DMA4 parameters		      	*/
#define pGP2A    ((volatile unsigned int *) 0x74)	   /* DMA4 General purpose		      				*/

/* DMA Channel 5 - Serial Port 2, B channel data */
#define pII2B    ((volatile unsigned int *) 0x90)	   /* Internal DMA5 memory address		      		*/
#define pIM2B    ((volatile unsigned int *) 0x91)	   /* Internal DMA5 memory access modifier	      	*/
#define pC2B     ((volatile unsigned int *) 0x92)	   /* Contains number of DMA5 transfers remaining   */
#define pCP2B    ((volatile unsigned int *) 0x93)	   /* Points to next DMA5 parameters		      	*/
#define pGP2B    ((volatile unsigned int *) 0x94)	   /* DMA5 General purpose		      				*/

/* DMA Channel 6 - Serial Port 3, A channel data */
#define pII3A    ((volatile unsigned int *) 0x78)	   /* Internal DMA6 memory address		      		*/
#define pIM3A    ((volatile unsigned int *) 0x79)	   /* Internal DMA6 memory access modifier	      	*/
#define pC3A     ((volatile unsigned int *) 0x7a)	   /* Contains number of DMA6 transfers remaining   */
#define pCP3A    ((volatile unsigned int *) 0x7b)	   /* Points to next DMA6 parameters		      	*/
#define pGP3A    ((volatile unsigned int *) 0x7c)	   /* DMA6 General purpose		      				*/

/* DMA Channel 7 - Serial Port 3, B channel data */
#define pII3B    ((volatile unsigned int *) 0x98)	   /* Internal DMA7 memory address		      		*/
#define pIM3B    ((volatile unsigned int *) 0x99)	   /* Internal DMA7 memory access modifier	        */
#define pC3B     ((volatile unsigned int *) 0x9a)	   /* Contains number of DMA7 transfers remaining   */
#define pCP3B    ((volatile unsigned int *) 0x9b)	   /* Points to next DMA7 parameters		      	*/
#define pGP3B    ((volatile unsigned int *) 0x9c)	   /* DMA7 General purpose		      				*/

/* DMA Channel 8 - Link Buffer 0 (or SPI Receive) */
#define pIILB0   ((volatile unsigned int *) 0x30)	   /* Internal DMA8 memory address		      		*/
#define pIMLB0   ((volatile unsigned int *) 0x31)	   /* Internal DMA8 memory access modifier	      	*/
#define pCLB0    ((volatile unsigned int *) 0x32)	   /* Contains number of DMA8 transfers remaining   */
#define pCPLB0   ((volatile unsigned int *) 0x33)	   /* Points to next DMA8 parameters		      	*/
#define pGPLB0   ((volatile unsigned int *) 0x34)	   /* DMA8 General purpose		      				*/

/* DMA Channel 8 -  SPI Receive (or Link Buffer 0) - No DMA Chain Pointer reg */
#define pIISRX   ((volatile unsigned int *) 0x30)	   /* Internal DMA8 memory address		      		*/
#define pIMSRX   ((volatile unsigned int *) 0x31)	   /* Internal DMA8 memory access modifier	      	*/
#define pCSRX    ((volatile unsigned int *) 0x32)	   /* Contains number of DMA8 transfers remaining   */
#define pGPSRX   ((volatile unsigned int *) 0x34)	   /* DMA8 General purpose		      				*/

/* DMA Channel 9 - Link Buffer 1 (or SPI Transmit) */
#define pIILB1   ((volatile unsigned int *) 0x38)	   /* Internal DMA9 memory address		      		*/
#define pIMLB1   ((volatile unsigned int *) 0x39)	   /* Internal DMA9 memory access modifier	      	*/
#define pCLB1    ((volatile unsigned int *) 0x3a)	   /* Contains number of DMA9 transfers remaining   */
#define pCPLB1   ((volatile unsigned int *) 0x3b)	   /* Points to next DMA9 parameters		      	*/
#define pGPLB1   ((volatile unsigned int *) 0x3c)	   /* DMA9 General purpose		      				*/

/* DMA Channel 9 -  SPI Transmit (or Link Buffer 1) - No DMA Chain Pointer reg */
#define pIISTX    ((volatile unsigned int *) 0x38)	   /* Internal DMA9 memory address		      		*/
#define pIMSTX    ((volatile unsigned int *) 0x39)	   /* Internal DMA9 memory access modifier	      	*/
#define pCSTX     ((volatile unsigned int *) 0x3a)	   /* Contains number of DMA9 transfers remainnig   */
#define pGPSTX    ((volatile unsigned int *) 0x3c)	   /* DMA9 General purpose */	

/* DMA Channel 10 - External Port FIFO Buffer 0 */
#define pIIEP0   ((volatile unsigned int *) 0x40)	   /* Internal DMA10 memory address					*/
#define pIMEP0   ((volatile unsigned int *) 0x41)	   /* Internal DMA10 memory access modifier	      	*/
#define pCEP0    ((volatile unsigned int *) 0x42)	   /* Contains number of DMA10 transfers remaining  */
#define pCPEP0   ((volatile unsigned int *) 0x43)	   /* Points to next DMA10 parameters		      	*/
#define pGPEP0   ((volatile unsigned int *) 0x44)	   /* DMA10 General purpose			      			*/
#define pEIEP0   ((volatile unsigned int *) 0x45)	   /* External DMA10 address			      		*/
#define pEMEP0   ((volatile unsigned int *) 0x46)	   /* External DMA10 address modifier		      	*/
#define pECEP0   ((volatile unsigned int *) 0x47)	   /* External DMA10 counter			      		*/

/* DMA Channel 11 - External Port FIFO Buffer 1 */
#define pIIEP1   ((volatile unsigned int *) 0x48)	   /* Internal DMA11 memory address		      		*/
#define pIMEP1   ((volatile unsigned int *) 0x49)	   /* Internal DMA11 memory access modifier	      	*/
#define pCEP1    ((volatile unsigned int *) 0x4a)	   /* Contains number of DMA11 transfers remaining  */
#define pCPEP1   ((volatile unsigned int *) 0x4b)	   /* Points to next DMA11 parameters		      	*/
#define pGPEP1   ((volatile unsigned int *) 0x4c)	   /* DMA11 General purpose			      			*/
#define pEIEP1   ((volatile unsigned int *) 0x4d)	   /* External DMA11 address			      		*/
#define pEMEP1   ((volatile unsigned int *) 0x4e)	   /* External DMA11 address modifier		      	*/
#define pECEP1   ((volatile unsigned int *) 0x4f)	   /* External DMA counter			      			*/

/* DMA Channel 12 - External Port FIFO Buffer 2 */
#define pIIEP2   ((volatile unsigned int *) 0x50)	   /* Internal DMA12 memory address		      		*/
#define pIMEP2   ((volatile unsigned int *) 0x51)	   /* Internal DMA12 memory access modifier	      	*/
#define pCEP2    ((volatile unsigned int *) 0x52)	   /* Contains number of DMA12 transfers remaining  */
#define pCPEP2   ((volatile unsigned int *) 0x53)	   /* Points to next DMA12 parameters		      	*/
#define pGPEP2   ((volatile unsigned int *) 0x54)	   /* DMA12 General purpose			      			*/
#define pEIEP2   ((volatile unsigned int *) 0x55)	   /* External DMA12 address			      		*/
#define pEMEP2   ((volatile unsigned int *) 0x56)	   /* External DMA12 address modifier		      	*/
#define pECEP2   ((volatile unsigned int *) 0x57)	   /* External DMA12 counter			      		*/

/* DMA Channel 13 - External Port FIFO Buffer 3 */
#define pIIEP3   ((volatile unsigned int *) 0x58)	   /* Internal DMA13 memory address		      		*/
#define pIMEP3   ((volatile unsigned int *) 0x59)	   /* Internal DMA13 memory access modifier	      	*/
#define pCEP3    ((volatile unsigned int *) 0x5a)	   /* Contains number of DMA13 transfers remaining  */
#define pCPEP3   ((volatile unsigned int *) 0x5b)	   /* Points to next DMA13 parameters		      	*/
#define pGPEP3   ((volatile unsigned int *) 0x5c)	   /* DMA13 General purpose			      			*/
#define pEIEP3   ((volatile unsigned int *) 0x5d)	   /* External DMA13 address			      		*/
#define pEMEP3   ((volatile unsigned int *) 0x5e)	   /* External DMA13 address modifier		     	*/
#define pECEP3   ((volatile unsigned int *) 0x5f)	   /* External DMA13 counter			      		*/


/*---- DMA Parameter Register Assignments - Old Legacy ADSP-21160 Naming Conventions ---- */
/* NOTE: For backwards compatibility, we can retain the old DMA parameter 
register names used in the ADSP-21160.  However, the naming conventions used for
DMA channels of the ADSP-21160 do not necessarily correspond to the actual DMA channel
priority assigment for the ADSP-21160

Ex) DMA Channel 4 IOP addresses on the ADSP-21160 are now DMA channel 8 on the ADSP-21161
    DMA Channel 5 IOP addresses on the ADSP-21160 are now DMA channel 9 on the ADSP-21161

To clear any confusion, we recommend using the new IOP naming conventions for the 
DMA parameter registers as defined above */

#define pII0    ((volatile unsigned int *) 0x60)	   /* Internal DMA0 memory address		      			*/
#define pIM0    ((volatile unsigned int *) 0x61)	   /* Internal DMA0 memory access modifier	      		*/
#define pC0     ((volatile unsigned int *) 0x62)	   /* Contains number of DMA0 transfers remaining     	*/
#define pCP0    ((volatile unsigned int *) 0x63)	   /* Points to next DMA0 parameters		      		*/
#define pGP0    ((volatile unsigned int *) 0x64)	   /* DMA0 General purpose 		      					*/

#define pII1    ((volatile unsigned int *) 0x68)	   /* Internal DMA1 memory address		      			*/
#define pIM1    ((volatile unsigned int *) 0x69)	   /* Internal DMA1 memory access modifier	      		*/
#define pC1     ((volatile unsigned int *) 0x6a)	   /* Contains number of DMA1 transfers remaining     	*/
#define pCP1    ((volatile unsigned int *) 0x6b)	   /* Points to next DMA1 parameters		      		*/
#define pGP1    ((volatile unsigned int *) 0x6c)	   /* DMA1 General purpose 		      					*/

#define pII2    ((volatile unsigned int *) 0x70)	   	/* Internal DMA2 memory address		      			*/
#define pIM2    ((volatile unsigned int *) 0x71)	   	/* Internal DMA2 memory access modifier	      		*/
#define pC2     ((volatile unsigned int *) 0x72)	   	/* Contains number of DMA2 transfers remaining     	*/
#define pCP2    ((volatile unsigned int *) 0x73)	   	/* Points to next DMA2 parameters		      		*/
#define pGP2    ((volatile unsigned int *) 0x74)	   	/* DMA2 General purpose		      					*/

#define pII3    ((volatile unsigned int *) 0x78)	   /* Internal DMA3 memory address		      			*/
#define pIM3    ((volatile unsigned int *) 0x79)	   /* Internal DMA3 memory access modifier	      		*/
#define pC3     ((volatile unsigned int *) 0x7a)	   /* Contains number of DMA3 transfers remaining     	*/
#define pCP3    ((volatile unsigned int *) 0x7b)	   /* Points to next DMA3 parameters		      		*/
#define pGP3    ((volatile unsigned int *) 0x7c)	   /* DMA3 General purpose 		      					*/

#define pII6    ((volatile unsigned int *) 0x80)	   /* Internal DMA6 memory address		      			*/
#define pIM6    ((volatile unsigned int *) 0x81)	   /* Internal DMA6 memory access modifier	      		*/
#define pC6     ((volatile unsigned int *) 0x82)	   /* Contains number of DMA6 transfers remaining     	*/
#define pCP6    ((volatile unsigned int *) 0x83)	   /* Points to next DMA6 parameters		      		*/
#define pGP6    ((volatile unsigned int *) 0x84)	   /* DMA6 General purpose 		      					*/

#define pII7    ((volatile unsigned int *) 0x88)	   /* Internal DMA7 memory address		      			*/
#define pIM7    ((volatile unsigned int *) 0x89)	   /* Internal DMA7 memory access modifier	      		*/
#define pC7     ((volatile unsigned int *) 0x8a)	   /* Contains number of DMA7 transfers remaining     	*/
#define pCP7    ((volatile unsigned int *) 0x8b)	   /* Points to next DMA7 parameters		      		*/
#define pGP7    ((volatile unsigned int *) 0x8c)	   /* DMA7 General purpose 		      					*/

#define pII8    ((volatile unsigned int *) 0x90)	   /* Internal DMA8 memory address		      			*/
#define pIM8    ((volatile unsigned int *) 0x91)	   /* Internal DMA8 memory access modifier	      		*/
#define pC8     ((volatile unsigned int *) 0x92)	   /* Contains number of DMA8 transfers remaining     	*/
#define pCP8    ((volatile unsigned int *) 0x93)	   /* Points to next DMA8 parameters		      		*/
#define pGP8	   ((volatile unsigned int *) 0x94)	   /* DMA8 General Purpose								*/

#define pII9    ((volatile unsigned int *) 0x98)	   /* Internal DMA9 memory address		      			*/
#define pIM9    ((volatile unsigned int *) 0x99)	   /* Internal DMA9 memory access modifier	      		*/
#define pC9     ((volatile unsigned int *) 0x9a)	   /* Contains number of DMA9 transfers remaining     	*/
#define pCP9    ((volatile unsigned int *) 0x9b)	   /* Points to next DMA9 parameters		      		*/
#define pGP9    ((volatile unsigned int *) 0x9c)	   /* DMA9 General purpose 		      					*/

#define pII4    ((volatile unsigned int *) 0x30)	   /* Internal DMA4 memory address		      			*/
#define pIM4    ((volatile unsigned int *) 0x31)	   /* Internal DMA4 memory access modifier	      		*/
#define pC4     ((volatile unsigned int *) 0x32)	   /* Contains number of DMA4 transfers remaining     	*/
#define pCP4    ((volatile unsigned int *) 0x33)	   /* Points to next DMA4 parameters		      		*/
#define pGP4    ((volatile unsigned int *) 0x34)	   /* DMA4 General purpose 		      					*/

#define pII5    ((volatile unsigned int *) 0x38)	   /* Internal DMA5 memory address		      			*/
#define pIM5    ((volatile unsigned int *) 0x39)	   /* Internal DMA5 memory access modifier	      		*/
#define pC5     ((volatile unsigned int *) 0x3a)	   /* Contains number of DMA5 transfers remaining     	*/
#define pCP5    ((volatile unsigned int *) 0x3b)	   /* Points to next DMA5 parameters		      		*/
#define pGP5    ((volatile unsigned int *) 0x3c)	   /* DMA5 General purpose 		      					*/

#define pII10   ((volatile unsigned int *) 0x40)	   /* Internal DMA10 memory address		      	  		*/
#define pIM10   ((volatile unsigned int *) 0x41)	   /* Internal DMA10 memory access modifier	      		*/
#define pC10    ((volatile unsigned int *) 0x42)	   /* Contains number of DMA10 transfers remaining    	*/
#define pCP10   ((volatile unsigned int *) 0x43)	   /* Points to next DMA10 parameters		      		*/
#define pGP10   ((volatile unsigned int *) 0x44)	   /* DMA10 General purpose			      		  		*/
#define pEI10   ((volatile unsigned int *) 0x45)	   /* External DMA10 address			      	  		*/
#define pEM10   ((volatile unsigned int *) 0x46)	   /* External DMA10 address modifier		      		*/
#define pEC10   ((volatile unsigned int *) 0x47)	   /* External DMA10 counter			      	  		*/

#define pII11   ((volatile unsigned int *) 0x48)	   /* Internal DMA11 memory address		      	  		*/
#define pIM11   ((volatile unsigned int *) 0x49)	   /* Internal DMA11 memory access modifier	      		*/
#define pC11    ((volatile unsigned int *) 0x4a)	   /* Contains number of DMA11 transfers remaining    	*/
#define pCP11   ((volatile unsigned int *) 0x4b)	   /* Points to next DMA11 parameters		      		*/
#define pGP11   ((volatile unsigned int *) 0x4c)	   /* DMA11 General purpose			      		  		*/
#define pEI11   ((volatile unsigned int *) 0x4d)	   /* External DMA11 address			      	  		*/
#define pEM11   ((volatile unsigned int *) 0x4e)	   /* External DMA11 address modifier		      		*/
#define pEC11   ((volatile unsigned int *) 0x4f)	   /* External DMA counter			      		  		*/

#define pII12   ((volatile unsigned int *) 0x50)	   /* Internal DMA12 memory address		      			*/
#define pIM12   ((volatile unsigned int *) 0x51)	   /* Internal DMA12 memory access modifier	      		*/
#define pC12    ((volatile unsigned int *) 0x52)	   /* Contains number of DMA12 transfers remaining    	*/
#define pCP12   ((volatile unsigned int *) 0x53)	   /* Points to next DMA12 parameters		      		*/
#define pGP12   ((volatile unsigned int *) 0x54)	   /* DMA12 General purpose			     	 			*/
#define pEI12   ((volatile unsigned int *) 0x55)	   /* External DMA12 address			      			*/
#define pEM12   ((volatile unsigned int *) 0x56)	   /* External DMA12 address modifier		      		*/
#define pEC12   ((volatile unsigned int *) 0x57)	   /* External DMA12 counter			      			*/

#define pII13   ((volatile unsigned int *) 0x58)	   /* Internal DMA13 memory address		      			*/
#define pIM13   ((volatile unsigned int *) 0x59)	   /* Internal DMA13 memory access modifier	      		*/
#define pC13    ((volatile unsigned int *) 0x5a)	   /* Contains number of DMA13 transfers remaining    	*/
#define pCP13   ((volatile unsigned int *) 0x5b)	   /* Points to next DMA13 parameters		      		*/
#define pGP13   ((volatile unsigned int *) 0x5c)	   /* DMA13 General purpose			      				*/
#define pEI13   ((volatile unsigned int *) 0x5d)	   /* External DMA13 address			      			*/
#define pEM13   ((volatile unsigned int *) 0x5e)	   /* External DMA13 address modifier		      		*/
#define pEC13   ((volatile unsigned int *) 0x5f)	   /* External DMA13 counter			      			*/


/* Emulation/Breakpoint Registers (remapped from UREG space) */
/*  NOTES: 
       - These registers are ONLY accessible by the core 
       - It is *highly* recommended that these facilities be accessed only
         through the ADI emulator routines
*/   
/* Core Emulation HWBD Registers */
#define pPSA1S  ((volatile unsigned int *) 0xa0)        /* Instruction address start #1                    */
#define pPSA1E  ((volatile unsigned int *) 0xa1)        /* Instruction address end   #1                    */
#define pPSA2S  ((volatile unsigned int *) 0xa2)        /* Instruction address start #2                    */
#define pPSA2E  ((volatile unsigned int *) 0xa3)        /* Instruction address end   #2                    */
#define pPSA3S  ((volatile unsigned int *) 0xa4)        /* Instruction address start #3                    */
#define pPSA3E  ((volatile unsigned int *) 0xa5)        /* Instruction address end   #3                    */
#define pPSA4S  ((volatile unsigned int *) 0xa6)        /* Instruction address start #4                    */
#define pPSA4E  ((volatile unsigned int *) 0xa7)        /* Instruction address end   #4                    */
#define pPMDAS  ((volatile unsigned int *) 0xa8)        /* Program Data address start                      */ 
#define pPMDAE  ((volatile unsigned int *) 0xa9)        /* Program Data address end                        */
#define pDMA1S  ((volatile unsigned int *) 0xaa)        /* Data address start #1                           */ 
#define pDMA1E  ((volatile unsigned int *) 0xab)        /* Data address end   #1                           */  
#define pDMA2S  ((volatile unsigned int *) 0xac)        /* Data address start #2                           */ 
#define pDMA2E  ((volatile unsigned int *) 0xad)        /* Data address end   #2                           */ 
#define pEMUN   ((volatile unsigned int *) 0xae)        /* hwbp hit-count register                         */

/* IOP Emulation HWBP Bounds Registers */
#define pIOAS   ((volatile unsigned int *) 0xb0)        /* IOA Upper Bounds Register                       */
#define pIOAE   ((volatile unsigned int *) 0xb1)        /* IOA Lower Bounds Register                       */
#define pEPAS   ((volatile unsigned int *) 0xb2)        /* EPA Upper Bounds Register                       */
#define pEPAE   ((volatile unsigned int *) 0xb3)        /* EPA Lower Bounds Register                       */

#endif
