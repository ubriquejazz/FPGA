/************************************************************************
 *
 * Cdef21062.h
 *
 * (c) Copyright 2001 Analog Devices, Inc.  All rights reserved.
 *
 ************************************************************************/

/* Cdef21062.h - $Date: 2002/03/13 11:04:38 $ */

/*
 * Cdef21062.h
 * Includes Cdef21060.h as there are no differences between 21060 and 21062.
 */


#ifndef ___CDEF21062.H
#define ___CDEF21062.H

#include <Cdef21060.h>

#endif // __CDEF21062.H
