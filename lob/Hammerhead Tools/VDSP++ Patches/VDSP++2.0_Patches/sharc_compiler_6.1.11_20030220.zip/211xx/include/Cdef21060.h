/************************************************************************
 *
 * Cdef21060.h
 *
 * (c) Copyright 2001 Analog Devices, Inc.  All rights reserved.
 *
 ************************************************************************/

/* Cdef21060.h - $Date: 2002/03/14 12:18:24 $ */

/* ----------------------------------------------------------------------------
Cdef21060.h - SYSTEM AND IOP REGISTER BIT AND ADDRESS DEFINITIONS FOR ADSP-21060

Last Modification on: $Date: 2002/03/14 12:18:24 $

This include file contains macros definitions of the IOP registers which
allow them to be used in C or C++ programs. Each macro is similar to that
in def21060.h, except that the macro is prefixed with 'p' and the relevant
casts are include in the macro definition. They can be used as follows:

	*pSYSTAT = 0x12345678;	// Set the SYSTAT register

---------------------------------------------------------------------------- */

/* I/O Processor Registers */
#define pSYSCON ((volatile unsigned int *) 0x00)	   /* System configuration register		     */
#define pVIRPT  ((volatile unsigned int *) 0x01)	   /* Vector interrupt register			     */
#define pWAIT   ((volatile unsigned int *) 0x02)	   /* Wait state configuration for external memory   */
#define pSYSTAT ((volatile unsigned int *) 0x03)	   /* System status register			     */
#define pEPB0   ((volatile unsigned int *) 0x04)	   /* External port DMA buffer 0		     */
#define pEPB1   ((volatile unsigned int *) 0x05)	   /* External port DMA buffer 1		     */
#define pEPB2   ((volatile unsigned int *) 0x06)	   /* External port DMA buffer 3		     */
#define pEPB3   ((volatile unsigned int *) 0x07)	   /* External port DMA buffer 4 		     */
#define pMSGR0  ((volatile unsigned int *) 0x08)	   /* Message register 0			     */
#define pMSGR1  ((volatile unsigned int *) 0x09)	   /* Message register 1			     */
#define pMSGR2  ((volatile unsigned int *) 0x0a)	   /* Message register 2			     */
#define pMSGR3  ((volatile unsigned int *) 0x0b)	   /* Message register 3			     */
#define pMSGR4  ((volatile unsigned int *) 0x0c)	   /* Message register 4			     */
#define pMSGR5  ((volatile unsigned int *) 0x0d)	   /* Message register 5			     */
#define pMSGR6  ((volatile unsigned int *) 0x0e)	   /* Message register 6			     */
#define pMSGR7  ((volatile unsigned int *) 0x0f)	   /* Message register 7			     */
#define pBMAX   ((volatile unsigned int *) 0x18)	   /* Bus time-out maximum			     */
#define pBCNT   ((volatile unsigned int *) 0x19)	   /* Bus time-out counter			     */
#define pELAST  ((volatile unsigned int *) 0x1b)	   /* Address of last external access for page detect*/
#define pDMAC6  ((volatile unsigned int *) 0x1c)	   /* EP DMA6 control register			     */
#define pDMAC7  ((volatile unsigned int *) 0x1d)	   /* EP DMA7 control register			     */
#define pDMAC8  ((volatile unsigned int *) 0x1e)	   /* EP DMA8 control register			     */
#define pDMAC9  ((volatile unsigned int *) 0x1f)	   /* EP DMA9 control register			     */

#define pII4    ((volatile unsigned int *) 0x30)	   /* Internal DMA4 memory address		     */
#define pIM4    ((volatile unsigned int *) 0x31)	   /* Internal DMA4 memory access modifier	     */
#define pC4     ((volatile unsigned int *) 0x32)	   /* Contains number of DMA4 transfers remaining    */
#define pCP4    ((volatile unsigned int *) 0x33)	   /* Points to next DMA4 parameters		     */
#define pGP4    ((volatile unsigned int *) 0x34)	   /* DMA4 General purpose / 2-D DMA		     */
#define pDB4    ((volatile unsigned int *) 0x35)	   /* DMA4 General purpose / 2-D DMA		     */
#define pDA4    ((volatile unsigned int *) 0x36)	   /* DMA4 General purpose / 2-D DMA		     */

#define pDMASTAT ((volatile unsigned int *) 0x37)	   /* DMA channel status register		     */

#define pII5    ((volatile unsigned int *) 0x38)	   /* Internal DMA5 memory address		     */
#define pIM5    ((volatile unsigned int *) 0x39)	   /* Internal DMA5 memory access modifier	     */
#define pC5     ((volatile unsigned int *) 0x3a)	   /* Contains number of DMA5 transfers remaining    */
#define pCP5    ((volatile unsigned int *) 0x3b)	   /* Points to next DMA5 parameters		     */
#define pGP5    ((volatile unsigned int *) 0x3c)	   /* DMA5 General purpose / 2-D DMA		     */
#define pDB5    ((volatile unsigned int *) 0x3d)	   /* DMA5 General purpose / 2-D DMA		     */
#define pDA5    ((volatile unsigned int *) 0x3e)	   /* DMA5 General purpose / 2-D DMA		     */

#define pII6    ((volatile unsigned int *) 0x40)	   /* Internal DMA6 memory address		     */
#define pIM6    ((volatile unsigned int *) 0x41)	   /* Internal DMA6 memory access modifier	     */
#define pC6     ((volatile unsigned int *) 0x42)	   /* Contains number of DMA6 transfers remaining    */
#define pCP6    ((volatile unsigned int *) 0x43)	   /* Points to next DMA6 parameters		     */
#define pGP6    ((volatile unsigned int *) 0x44)	   /* DMA6 General purpose			     */
#define pEI6    ((volatile unsigned int *) 0x45)	   /* External DMA6 address			     */
#define pEM6    ((volatile unsigned int *) 0x46)	   /* External DMA6 address modifier		     */
#define pEC6    ((volatile unsigned int *) 0x47)	   /* External DMA6 counter			     */

#define pII7    ((volatile unsigned int *) 0x48)	   /* Internal DMA7 memory address		     */
#define pIM7    ((volatile unsigned int *) 0x49)	   /* Internal DMA7 memory access modifier	     */
#define pC7     ((volatile unsigned int *) 0x4a)	   /* Contains number of DMA7 transfers remaining    */
#define pCP7    ((volatile unsigned int *) 0x4b)	   /* Points to next DMA7 parameters		     */
#define pGP7    ((volatile unsigned int *) 0x4c)	   /* DMA7 General purpose			     */
#define pEI7    ((volatile unsigned int *) 0x4d)	   /* External DMA7 address			     */
#define pEM7    ((volatile unsigned int *) 0x4e)	   /* External DMA7 address modifier		     */
#define pEC7    ((volatile unsigned int *) 0x4f)	   /* External DMA7 counter			     */

#define pII8    ((volatile unsigned int *) 0x50)	   /* Internal DMA8 memory address		     */
#define pIM8    ((volatile unsigned int *) 0x51)	   /* Internal DMA8 memory access modifier	     */
#define pC8     ((volatile unsigned int *) 0x52)	   /* Contains number of DMA8 transfers remaining    */
#define pCP8    ((volatile unsigned int *) 0x53)	   /* Points to next DMA8 parameters		     */
#define pGP8    ((volatile unsigned int *) 0x54)	   /* DMA8 General purpose			     */
#define pEI8    ((volatile unsigned int *) 0x55)	   /* External DMA8 address			     */
#define pEM8    ((volatile unsigned int *) 0x56)	   /* External DMA8 address modifier		     */
#define pEC8    ((volatile unsigned int *) 0x57)	   /* External DMA8 counter			     */

#define pII9    ((volatile unsigned int *) 0x58)	   /* Internal DMA9 memory address		     */
#define pIM9    ((volatile unsigned int *) 0x59)	   /* Internal DMA9 memory access modifier	     */
#define pC9     ((volatile unsigned int *) 0x5a)	   /* Contains number of DMA9 transfers remaining    */
#define pCP9    ((volatile unsigned int *) 0x5b)	   /* Points to next DMA9 parameters		     */
#define pGP9    ((volatile unsigned int *) 0x5c)	   /* DMA9 General purpose			     */
#define pEI9    ((volatile unsigned int *) 0x5d)	   /* External DMA9 address			     */
#define pEM9    ((volatile unsigned int *) 0x5e)	   /* External DMA9 address modifier		     */
#define pEC9    ((volatile unsigned int *) 0x5f)	   /* External DMA9 counter			     */

#define pII0    ((volatile unsigned int *) 0x60)	   /* Internal DMA0 memory address		     */
#define pIM0    ((volatile unsigned int *) 0x61)	   /* Internal DMA0 memory access modifier	     */
#define pC0     ((volatile unsigned int *) 0x62)	   /* Contains number of DMA0 transfers remaining    */
#define pCP0    ((volatile unsigned int *) 0x63)	   /* Points to next DMA0 parameters		     */
#define pGP0    ((volatile unsigned int *) 0x64)	   /* DMA0 General purpose / 2-D DMA		     */
#define pDB0    ((volatile unsigned int *) 0x65)	   /* DMA0 General purpose / 2-D DMA		     */
#define pDA0    ((volatile unsigned int *) 0x66)	   /* DMA0 General purpose / 2-D DMA		     */

#define pII1    ((volatile unsigned int *) 0x68)	   /* Internal DMA1 memory address		     */
#define pIM1    ((volatile unsigned int *) 0x69)	   /* Internal DMA1 memory access modifier	     */
#define pC1     ((volatile unsigned int *) 0x6a)	   /* Contains number of DMA1 transfers remaining    */
#define pCP1    ((volatile unsigned int *) 0x6b)	   /* Points to next DMA1 parameters		     */
#define pGP1    ((volatile unsigned int *) 0x6c)	   /* DMA1 General purpose / 2-D DMA		     */
#define pDB1    ((volatile unsigned int *) 0x6d)	   /* DMA1 General purpose / 2-D DMA		     */
#define pDA1    ((volatile unsigned int *) 0x6e)	   /* DMA1 General purpose / 2-D DMA		     */

#define pII2    ((volatile unsigned int *) 0x70)	   /* Internal DMA2 memory address		     */
#define pIM2    ((volatile unsigned int *) 0x71)	   /* Internal DMA2 memory access modifier	     */
#define pC2     ((volatile unsigned int *) 0x72)	   /* Contains number of DMA2 transfers remaining    */
#define pCP2    ((volatile unsigned int *) 0x73)	   /* Points to next DMA2 parameters		     */
#define pGP2    ((volatile unsigned int *) 0x74)	   /* DMA2 General purpose / 2-D DMA		     */
#define pDB2    ((volatile unsigned int *) 0x75)	   /* DMA2 General purpose / 2-D DMA		     */
#define pDA2    ((volatile unsigned int *) 0x76)	   /* DMA2 General purpose / 2-D DMA		     */

#define pII3    ((volatile unsigned int *) 0x78)        /* Internal DMA3 memory address		     */
#define pIM3    ((volatile unsigned int *) 0x79)        /* Internal DMA3 memory access modifier	     */
#define pC3     ((volatile unsigned int *) 0x7a)        /* Contains number of DMA3 transfers remaining    */
#define pCP3    ((volatile unsigned int *) 0x7b)        /* Points to next DMA3 parameters		     */
#define pGP3    ((volatile unsigned int *) 0x7c)        /* DMA3 General purpose / 2-D DMA		     */
#define pDB3    ((volatile unsigned int *) 0x7d)        /* DMA3 General purpose / 2-D DMA		     */
#define pDA3    ((volatile unsigned int *) 0x7e)        /* DMA3 General purpose / 2-D DMA		     */

#define pLBUF0  ((volatile unsigned int *) 0xc0)	   /* Link buffer 0				     */
#define pLBUF1  ((volatile unsigned int *) 0xc1)	   /* Link buffer 1				     */
#define pLBUF2  ((volatile unsigned int *) 0xc2)	   /* Link buffer 2				     */
#define pLBUF3  ((volatile unsigned int *) 0xc3)	   /* Link buffer 3				     */
#define pLBUF4  ((volatile unsigned int *) 0xc4)	   /* Link buffer 4				     */
#define pLBUF5  ((volatile unsigned int *) 0xc5)	   /* Link buffer 5				     */
#define pLCTL   ((volatile unsigned int *) 0xc6)	   /* Link buffer control			     */
#define pLCOM   ((volatile unsigned int *) 0xc7)	   /* Link common control			     */
#define pLAR    ((volatile unsigned int *) 0xc8)	   /* Link assignment register			     */
#define pLSRQ   ((volatile unsigned int *) 0xc9)	   /* Link service request and mask register	     */
#define pLPATH1 ((volatile unsigned int *) 0xca)	   /* Link path register 1			     */
#define pLPATH2 ((volatile unsigned int *) 0xcb)	   /* Link path register 2			     */
#define pLPATH3 ((volatile unsigned int *) 0xcc)	   /* Link path register 3			     */
#define pLPCNT  ((volatile unsigned int *) 0xcd)	   /* Link path counter				     */
#define pCNST1  ((volatile unsigned int *) 0xce)	   /* Link port constant 1 register		     */
#define pCNST2  ((volatile unsigned int *) 0xcf)	   /* Link port constant 2 register		     */

			   /* Serial Port 0: */
#define pSTCTL0 ((volatile unsigned int *) 0xe0)        /*  SPORT0 Transmit Control Register              */
#define pSRCTL0 ((volatile unsigned int *) 0xe1)        /*  SPORT0 Receive Control Register               */
#define pTX0    ((volatile unsigned int *) 0xe2)        /*  SPORT0 Transmit Data Buffer                   */
#define pRX0    ((volatile unsigned int *) 0xe3)        /*  SPORT0 Receive Data Buffer                    */
#define pTDIV0  ((volatile unsigned int *) 0xe4)        /*  SPORT0 Transmit Divisor                       */
#define pTCNT0  ((volatile unsigned int *) 0xe5)        /*  SPORT0 Transmit Count Reg                     */
#define pRDIV0  ((volatile unsigned int *) 0xe6)        /*  SPORT0 Receive Divisor                        */
#define pRCNT0  ((volatile unsigned int *) 0xe7)        /*  SPORT0 Receive Count Reg                      */
#define pMTCS0  ((volatile unsigned int *) 0xe8)        /*  SPORT0 Multichannel Transmit Selector         */
#define pMRCS0  ((volatile unsigned int *) 0xe9)        /*  SPORT0 Multichannel Receive Selector          */
#define pMTCCS0 ((volatile unsigned int *) 0xea)        /*  SPORT0 Multichannel Transmit Selector         */
#define pMRCCS0 ((volatile unsigned int *) 0xeb)        /*  SPORT0 Multichannel Receive Selector          */
#define pSPATH0 ((volatile unsigned int *) 0xee)        /*  SPORT0 Path Length (Mesh Multiprocessing)     */
#define pSPCNT0 ((volatile unsigned int *) 0xef)        /*  SPORT0 Path Counter (Mesh Multiprocessing)    */

			   /* Serial Port 1: */
#define pSTCTL1 ((volatile unsigned int *) 0xf0)        /*  SPORT1 Transmit Control Register              */
#define pSRCTL1 ((volatile unsigned int *) 0xf1)        /*  SPORT1 Receive  Control Register              */
#define pTX1    ((volatile unsigned int *) 0xf2)        /*  SPORT1 Transmit Data Buffer                   */
#define pRX1    ((volatile unsigned int *) 0xf3)        /*  SPORT1 Receive Data Buffer                    */
#define pTDIV1  ((volatile unsigned int *) 0xf4)        /*  SPORT1 Transmit Divisor                       */
#define pTCNT1  ((volatile unsigned int *) 0xf5)        /*  SPORT1 Transmit Count Reg                     */
#define pRDIV1  ((volatile unsigned int *) 0xf6)        /*  SPORT1 Receive Divisor                        */
#define pRCNT1  ((volatile unsigned int *) 0xf7)        /*  SPORT1 Receive Count Reg                      */
#define pMTCS1  ((volatile unsigned int *) 0xf8)        /*  SPORT1 Multichannel Transmit Selector         */
#define pMRCS1  ((volatile unsigned int *) 0xf9)        /*  SPORT1 Multichannel Receive Selector          */
#define pMTCCS1 ((volatile unsigned int *) 0xfa)        /*  SPORT1 Multichannel Transmit Selector         */
#define pMRCCS1 ((volatile unsigned int *) 0xfb)        /*  SPORT1 Multichannel Receive Selector          */
#define pSPATH1 ((volatile unsigned int *) 0xfe)        /*  SPORT1 Path Length (Mesh Multiprocessing)     */
#define pSPCNT1 ((volatile unsigned int *) 0xff)        /*  SPORT1 Path Counter (Mesh Multiprocessing)    */
