/*
 *  support for saturation mode arithmetic  (add, subtract)
 *
 * 
 * - general mode change
 * - local operations in given mode
 *
  Saturation arithmetic is useful in signal processing.  When a
computation yields a value outside of the representable range,
saturation logic in the hardware replaces that with the largest
representable value for that type.  Note that the "clip" operation is
also available for manually enforcing range limits efficiently.
  For fractional arithmetic, multiplication cannot overflow (except for
one special case, -1 * -1).  Addition and subtraction can overflow, and
thus are candidates for saturation.

  On the 21xxx and 21xx processors, saturation mode for ALU
operations is determined by a machine mode, rather than a bit in
a particular instruction.  The operations defined in this header
provide several different mechanisms for controlling the use of
saturation within a user program.   The choice will be governed by
considerations of efficiency, and also the characteristics of other
parts of the program.
  MAC accumulation has special support, which is not addressed herein.


Note that the mode change affects both fract and integer operations.  


1. mode change
operations:     set_saturate_mode,  reset_saturate_mode
  These operations change the machine mode.  The new mode stays in
effect until explicitly changed again.
  This provides for highest efficiency: one need only pay the small
overhead of the mode change once.  There are some drawbacks, however:
some code may depend on overflow/truncation effects; they won't work
correctly with saturation enabled.  The random number generator is one
such routine.  
  At this time, Analog has not yet fully tested the library to determine
which portions can reliably run in saturate mode.  Users wishing to
change mode globally should verify correct behavior for their
applications. 

2. change for one statement
operations:  SATURATE, UNSATURATE, SAFE_SATURATE, SAFE_UNSATURATE

  These statement-level macros execute one or more statements in an
environment of the indicated mode.  This provides temporary mode
shifting, and thus avoid the problems of possible complications from
other portions of the program.  There is a small price, in the
instructions needed to change and restore the mode:  5 cycles for each
simple operations, 6 for the "SAFE_" operations.
  Note that both SATURATE and UNSATURATE versions are available, for use
in either global mode.  Also, as these operations save and restore the
pre-existing mode, they are safe to use when the prevailing mode may not
be known.
   
  The "SAFE_" variants additionally lock out interrupts for the duration
of the computation.  This would be appropriate if the program contained
interrupt code which could not safely run in the wrong mode. 


3.  perform a single operation
operations:  add_sat, add_unsat, sub_sat, sub_unsat, neg_sat, neg_unsat 

  These functions perform a single operation in the indicated mode.  As
functions, they may be part of larger expressions, be nested, etc.
  As with the previous set of operations, these functions save and
restore the existing state.  Overhead is similar, 5 cycles.
  No "SAFE_" variants have been provided.  The statement-level macros
can be used instead, or you can inspect the code herein and construct
your own.

  Note that "neg" (negate) can only saturate for one value, -1.

  The single operation functions are provided for "fract" data.  
If integer versions are desired, simply copy the bodies and change 
"fract" to "int" throughout.

 */


#ifndef __SATURATE_DEFINED
#define __SATURATE_DEFINED

#include <sysreg.h>

#if defined(__ADSP21000__)
/* bits in MODE1 */
#  define _SAT_MODE sysreg_MODE1
#  define _IRPTEN  0x00001000 /* Bit 12: Global interrupt enable              */
#  define _ALUSAT  0x00002000 /* Bit 13: Enable ALU fixed-pt. saturation      */
/* (forms suitable for use in asm statments) */
#  define _qIRPTEN  "0x00001000" 
#  define _qALUSAT  "0x00002000"
#elif defined(__ADSP21XX__) || defined (__ADSP219X__)
#  define _SAT_MODE sysreg_MSTAT
#  include <def219x.h>
#  define _IRPTEN  ICNTL_GIE    /* ICNTL-Bit 5: Global interrupt enable       */
#  define _ALUSAT  MSTAT_AR_SAT /* MSTAT-Bit 3: ALU result saturation enable  */
#else
#  error -  Not configured
#endif


/***************************************************************
 *  set_saturate_mode,  reset_saturate_mode : global mode change
 *
 * time:  2 cycles          arguments:  none
 ***************************************************************/

inline static 
void set_saturate_mode() {
#if defined(__ADSP21000__)
  sysreg_bit_set_nop(_SAT_MODE, _ALUSAT);
#elif defined(__ADSP219X__)
  mode_change(__MODE_ENA_AR_SAT);
#endif
}

inline static 
void reset_saturate_mode() {
#if defined(__ADSP21000__)
  sysreg_bit_clr_nop(_SAT_MODE, _ALUSAT);
#elif defined(__ADSP219X__)
  mode_change(__MODE_DIS_AR_SAT);
#endif
}

/***************************************************************
 *  SATURATE, UNSATURATE, SAFE_SATURATE, SAFE_UNSATURATE
 *
 *    Statement-level local mode change  (previous mode restored)
 * time:  5 cycles (6 cycles for SAFE_ versions) 
 * arguments:  statement or statements to be executed
 *
 ***************************************************************/


#if defined(__ADSP21000__) 

#if !defined(__NO_BUILTIN) && !defined(__GNUC__)
#define _NOP()     __builtin_NOP()
#endif

#define SATURATE(stmt) \
 {const int _prev_mode1 = sysreg_read(sysreg_MODE1); \
  sysreg_bit_set_nop(sysreg_MODE1, _ALUSAT); \
  stmt; \
  sysreg_write_nop(sysreg_MODE1, _prev_mode1);\
 }

#define UNSATURATE(stmt) \
 {const int _prev_mode1 = sysreg_read(sysreg_MODE1); \
  sysreg_bit_clr_nop(sysreg_MODE1, _ALUSAT);\
  stmt; \
  sysreg_write_nop(sysreg_MODE1, _prev_mode1);\
 }

#define SAFE_SATURATE(stmt) \
 {const int _prev_mode1 = sysreg_read(sysreg_MODE1); \
 asm volatile ("jump (pc,3)(DB); bit clr MODE1 "_qIRPTEN"; bit set MODE1 "_qALUSAT"; nop;");\
  stmt; \
  sysreg_write_nop(sysreg_MODE1, _prev_mode1);\
 }

#define SAFE_UNSATURATE(stmt) \
 {const int _prev_mode1 = sysreg_read(sysreg_MODE1); \
 asm volatile ("jump (pc,3)(DB); bit clr MODE1 "_qIRPTEN" | "_qALUSAT"; nop;");\
  stmt; \
  sysreg_write_nop(sysreg_MODE1, _prev_mode1); \
 }

/* note:  the instructions in the branch delay slot are protected 
 from interrupt.  This is the only safe way to turn off the interrupt
 system;  otherwise, an interrupt might occur after the bit was 
 cleared but before the change took effect;  the intervening interrupt
 routine would then, on dismissing, re-enable interrupts!
*/

#else defined(__ADSP21XX__)

#define SATURATE(stmt) \
 {const int _prev_mstat = sysreg_read(sysreg_MSTAT); \
  mode_change(__MODE_ENA_AR_SAT); \
  stmt; \
  sysreg_write(sysreg_MSTAT, _prev_mstat);\
 }

#define UNSATURATE(stmt) \
 {const int _prev_mstat = sysreg_read(sysreg_MSTAT); \
  mode_change(__MODE_DIS_AR_SAT);\
  stmt; \
  sysreg_write(sysreg_MSTAT, _prev_mstat);\
 }

#define SAFE_SATURATE(stmt) \
 {const int _prev_mstat = sysreg_read(sysreg_MSTAT); \
  const int _prev_icntl = sysreg_read(sysreg_ICNTL); \
  mode_change(__MODE_ENA_AR_SAT|__MODE_DIS_INT); \
  stmt; \
  sysreg_write(sysreg_MSTAT, _prev_mstat); \
  sysreg_write(sysreg_ICNTL, _prev_icntl); \
 }

#define SAFE_UNSATURATE(stmt) \
 {const int _prev_mstat = sysreg_read(sysreg_MSTAT); \
  const int _prev_icntl = sysreg_read(sysreg_ICNTL); \
  mode_change(__MODE_DIS_AR_SAT|__MODE_DIS_INT); \
  stmt; \
  sysreg_write(sysreg_MSTAT, _prev_mstat); \
  sysreg_write(sysreg_ICNTL, _prev_icntl); \
 }

#endif

#ifdef __FRACT_DEFINED


/***************************************************************
 *   add_sat, add_unsat, sub_sat, sub_unsat, neg_sat, neg_unsat 
 *
 *    fract functions with local mode change  (previous mode restored)
 * time:  5 cycles (7 for SAFE_ versions
 * arguments: operands of particular operator
 *
 ***************************************************************/



#if defined(__ADSP21000__) || defined(__ADSP21XX__)


#define add_sat	__builtin_add_sat
#define add_unsat	__builtin_add_unsat
#define sub_sat	__builtin_sub_sat
#define sub_unsat	__builtin_sub_unsat
#define neg_sat	__builtin_neg_sat
#define neg_unsat	__builtin_neg_unsat

extern "C" {

fract __builtin_add_sat (fract a, fract b);
fract __builtin_add_unsat (fract a, fract b);
fract __builtin_sub_sat (fract a, fract b);
fract __builtin_sub_unsat (fract a, fract b);
fract __builtin_neg_sat (fract a);
fract __builtin_neg_unsat (fract a);

}


#else

/*	These versions may suffer from the compiler frontend optimizer
	reordering function calls to change mode registers around the 
	instruction that is dependant on the value of the mode 
	register. */

static inline
fract add_sat (fract a, fract b) {
  const int
    _prev_mode = sysreg_read(_SAT_MODE); 
  fract result; 
  sysreg_bit_set_nop(sat_MODE, _ALUSAT); 
  result = a + b;
  sysreg_write_nop(sat_MODE, _prev_mode);
  return result;
 }


static inline
fract add_unsat (fract a, fract b) {
  const int
    _prev_mode = sysreg_read(_SAT_MODE); 
  fract result; 
  sysreg_bit_clr_nop(_SAT_MODE, _ALUSAT); 
  result = a + b;
  sysreg_write_nop(_SAT_MODE, _prev_mode);
  return result;
 }

static inline
fract sub_sat (fract a, fract b) {
  const int
    _prev_mode = sysreg_read(_SAT_MODE); 
  fract result; 
  sysreg_bit_set_nop(_SAT_MODE, _ALUSAT); 
  result = a - b;
  sysreg_write_nop(_SAT_MODE, _prev_mode);
  return result;
 }

static inline
fract sub_unsat (fract a, fract b) {
  const int
    _prev_mode = sysreg_read(_SAT_MODE); 
  fract result; 
  sysreg_bit_clr_nop(_SAT_MODE, _ALUSAT); 
  result = a - b;
  sysreg_write_nop(_SAT_MODE, _prev_mode);
  return result;
 }


static inline
fract neg_sat (fract a) {
  const int
    _prev_mode = sysreg_read(_SAT_MODE); 
  fract result; 
  sysreg_bit_set_nop(_SAT_MODE, _ALUSAT); 
  result = -a;
  sysreg_write_nop(_SAT_MODE, _prev_mode);
  return result;
 }

static inline
fract neg_unsat (fract a) {
  const int
    _prev_mode = sysreg_read(_SAT_MODE); 
  fract result; 
  sysreg_bit_clr_nop(_SAT_MODE, _ALUSAT); 
  result = -a;
  sysreg_write_nop(_SAT_MODE, _prev_mode);
  return result;
 }
#endif

#endif  /* FRACT_DEFINED */


#endif  /* SATURATE_DEFINED - include guard */


