/* Various functions built into the compiler */

#ifndef __BUILTINS_DEFINED
#define __BUILTINS_DEFINED

#ifdef __cplusplus
extern "C" {
#endif


void __builtin_NOP();
int __builtin_avg(int ,int );
float __builtin_favgf(float ,float );
float __builtin_fsignf(float ,float );
int __builtin_clip(int ,int );
float __builtin_fclipf(float ,float );
float __builtin_copysignf(float ,float );
int __builtin_conv_RtoLR(int );
int __builtin_conv_LRtoR(int );
float __builtin_conv_RtoF(int );
int __builtin_conv_FtoR(float );
int __builtin_RxR(int ,int );
int __builtin_LRxLR(int ,int );
int __builtin_RxItoI(int ,int );
int __builtin_RxItoR(int ,int );
void __builtin_enter_simd();
void __builtin_exit_simd();
int __builtin_simd_sum(int );
int __builtin_simd_sumIU(unsigned );
unsigned __builtin_simd_sumUI(int );
unsigned __builtin_simd_sumUU(unsigned );
float __builtin_simd_fsum(float );
int __builtin_shadow_reg(int );
unsigned int __builtin_sysreg_read(int );
void __builtin_sysreg_write(int ,unsigned int );
void __builtin_sysreg_bit_set(int ,unsigned int );
void __builtin_sysreg_bit_clr(int ,unsigned int );
void __builtin_sysreg_bit_tgl(int ,unsigned int );
int __builtin_sysreg_bit_tst(int ,unsigned int );
int __builtin_sysreg_bit_tst_all(int ,unsigned int );

#ifdef __cplusplus
};
#endif

#endif             
