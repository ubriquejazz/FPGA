/************************************************************************
 *
 * Cdef21160.h
 *
 * (c) Copyright 2001 Analog Devices, Inc.  All rights reserved.
 *
 ************************************************************************/

/* -----------------------------------------------------------------------------
Cdef21160.h - SYSTEM & IOP REGISTER BIT & ADDRESS DEFINITIONS FOR ADSP-21160

This include file contains macros definitions of the IOP registers which
allow them to be used in C or C++ programs. Each macro is similar to that
in def21160.h, except that the macro is prefixed with 'p' and the relevant
casts are include in the macro definition. They can be used as follows:

   *pSYSTAT = 0x12345678;  // Set the SYSTAT register

--------------------------------------------------------------------------------*/
#ifndef __CDEF21160_H_
#define p__CDEF21160_H_ 

/*------------------------------------------------------------------------------*/
/*                System Register bit definitions                             	*/
/*------------------------------------------------------------------------------*/

/*                     I/O Processor Register Map                             	*/
/*------------------------------------------------------------------------------*/
#define pSYSCON ((volatile unsigned int *) 0x00)        	/* System configuration register                   	*/
#define pVIRPT  ((volatile unsigned int *) 0x01)        	/* Vector interrupt register                       	*/
#define pWAIT   ((volatile unsigned int *) 0x02)        	/* External Port Wait register - renamed to EPCON  	*/
#define pEPCON  ((volatile unsigned int *) 0x02)        	/* External Port configuration register            	*/
#define pSYSTAT ((volatile unsigned int *) 0x03)        	/* System status register                          	*/
/* the upper 32-bits of the 64-bit epbxs are only accessible as 64-bit reference*/
#define pEPB0   ((volatile unsigned int *) 0x04)        	/* External port DMA buffer 0                      	*/
#define pEPB1   ((volatile unsigned int *) 0x06)        	/* External port DMA buffer 1                      	*/
#define pMSGR0  ((volatile unsigned int *) 0x08)        	/* Message register 0                              	*/
#define pMSGR1  ((volatile unsigned int *) 0x09)        	/* Message register 1                              	*/
#define pMSGR2  ((volatile unsigned int *) 0x0a)        	/* Message register 2                              	*/
#define pMSGR3  ((volatile unsigned int *) 0x0b)        	/* Message register 3                              	*/
#define pMSGR4  ((volatile unsigned int *) 0x0c)        	/* Message register 4                              	*/
#define pMSGR5  ((volatile unsigned int *) 0x0d)        	/* Message register 5                              	*/
#define pMSGR6  ((volatile unsigned int *) 0x0e)        	/* Message register 6                              	*/
#define pMSGR7  ((volatile unsigned int *) 0x0f)        	/* Message register 7                              	*/
	
/* IOP shadow registers of the core control regs                              	*/
#define pPC_SHDW    ((volatile unsigned int *) 0x10)	   	/* PC IOP shadow register (PC[23-0])               	*/
#define pMODE2_SHDW ((volatile unsigned int *) 0x11)	   	/* Mode2 IOP shadow register (MODE2[31-25])        	*/
#define pEPB2   		((volatile unsigned int *) 0x14)        	/* EXternal port DMA buffer 2                      	*/
#define pEPB3   		((volatile unsigned int *) 0x16)        	/* External port DMA buffer 3                      	*/
#define pBMAX   		((volatile unsigned int *) 0x18)	   	   	/* Bus time-out maximum			      			  	*/
#define pBCNT   		((volatile unsigned int *) 0x19)	       	/* Bus time-out counter			      			  	*/
#define pELAST  		((volatile unsigned int *) 0x1b)	       	/* Address of last external access for page detect 	*/
#define pDMAC10 		((volatile unsigned int *) 0x1c)	       	/* EP DMA10 control register			      		*/
#define pDMAC11 		((volatile unsigned int *) 0x1d)	       	/* EP DMA11 control register			      		*/
#define pDMAC12 		((volatile unsigned int *) 0x1e)	       	/* EP DMA12 control register			      		*/
#define pDMAC13 		((volatile unsigned int *) 0x1f)	       	/* EP DMA13 Control register			      		*/

#define pII4    		((volatile unsigned int *) 0x30)	   		/* Internal DMA4 memory address		      	 		*/
#define pIM4    		((volatile unsigned int *) 0x31)	   		/* Internal DMA4 memory access modifier	     		*/
#define pC4     		((volatile unsigned int *) 0x32)	   		/* Contains number of DMA4 transfers remaining  	*/
#define pCP4    		((volatile unsigned int *) 0x33)	   		/* Points to next DMA4 parameters	      			*/
#define pGP4    		((volatile unsigned int *) 0x34)	   		/* DMA4 General purpose / 2-D DMA	      			*/
#define pDB4    		((volatile unsigned int *) 0x35)	   		/* DMA4 General purpose / 2-D DMA	      			*/
#define pDA4    		((volatile unsigned int *) 0x36)	   		/* DMA4 General purpose / 2-D DMA	      			*/

#define pDMASTAT 		((volatile unsigned int *) 0x37)	   	/* DMA channel status register		      			*/

#define pII5    		((volatile unsigned int *) 0x38)	   		/* Internal DMA5 memory address		      			*/
#define pIM5    		((volatile unsigned int *) 0x39)	   		/* Internal DMA5 memory access modifier	      		*/
#define pC5     		((volatile unsigned int *) 0x3a)	   		/* Contains number of DMA5 transfers remainnig     	*/
#define pCP5    		((volatile unsigned int *) 0x3b)	   		/* Points to next DMA5 parameters		      		*/
#define pGP5    		((volatile unsigned int *) 0x3c)	   		/* DMA5 General purpose / 2-D DMA		      		*/
#define pDB5    		((volatile unsigned int *) 0x3d)	   		/* DMA5 General pu	rpose / 2-D DMA		      		*/
#define pDA5    		((volatile unsigned int *) 0x3e)	   		/* DMA5 General purpose / 2-D DMA		      		*/

#define pII10   		((volatile unsigned int *) 0x40)	   		/* Internal DMA10 memory address		      		*/
#define pIM10   		((volatile unsigned int *) 0x41)	   		/* Internal DMA10 memory access modifier	      	*/
#define pC10    		((volatile unsigned int *) 0x42)	   		/* Contains number of DMA10 transfers remainnig    	*/
#define pCP10   		((volatile unsigned int *) 0x43)	   		/* Points to next DMA10 parameters		      		*/
#define pGP10   		((volatile unsigned int *) 0x44)	   		/* DMA10 General purpose			      			*/
#define pEI10   		((volatile unsigned int *) 0x45)	   		/* External DMA10 address			      			*/
#define pEM10   		((volatile unsigned int *) 0x46)	   		/* External DMA10 address modifier		      		*/
#define pEC10   		((volatile unsigned int *) 0x47)	   		/* External DMA10 counter			      			*/

#define pII11   		((volatile unsigned int *) 0x48)	   		/* Internal DMA11 memory address		      		*/
#define pIM11   		((volatile unsigned int *) 0x49)	   		/* Internal DMA11 memory access modifier	      	*/
#define pC11    		((volatile unsigned int *) 0x4a)	   		/* Contains number of DMA11 transfers remainnig    	*/
#define pCP11   		((volatile unsigned int *) 0x4b)	   		/* Points to next DMA11 parameters		      		*/
#define pGP11   		((volatile unsigned int *) 0x4c)	   		/* DMA11 General purpose			      			*/
#define pEI11   		((volatile unsigned int *) 0x4d)	   		/* External DMA11 address			      			*/
#define pEM11   		((volatile unsigned int *) 0x4e)	   		/* External DMA11 address modifier		      		*/
#define pEC11   		((volatile unsigned int *) 0x4f)	   		/* External DMA counter			      				*/

#define pII12   		((volatile unsigned int *) 0x50)	   		/* Internal DMA12 memory address		      		*/
#define pIM12   		((volatile unsigned int *) 0x51)	   		/* Internal DMA12 memory access modifier	      	*/
#define pC12    		((volatile unsigned int *) 0x52)	   		/* Contains number of DMA12 transfers remainnig    	*/
#define pCP12   		((volatile unsigned int *) 0x53)	   		/* Points to next DMA12 parameters		      		*/
#define pGP12  	 		((volatile unsigned int *) 0x54)	   		/* DMA12 General purpose			      			*/
#define pEI12   		((volatile unsigned int *) 0x55)	   		/* External DMA12 address			      			*/
#define pEM12   		((volatile unsigned int *) 0x56)	   		/* External DMA12 address modifier		      		*/
#define pEC12   		((volatile unsigned int *) 0x57)	   		/* External DMA12 counter			      			*/

#define pII13   ((volatile unsigned int *) 0x58)	   		/* Internal DMA13 memory address		      		*/
#define pIM13   ((volatile unsigned int *) 0x59)	   		/* Internal DMA13 memory access modifier	      	*/
#define pC13    ((volatile unsigned int *) 0x5a)	   		/* Contains number of DMA13 transfers remainnig    	*/
#define pCP13   ((volatile unsigned int *) 0x5b)	   		/* Points to next DMA13 parameters		      		*/
#define pGP13   ((volatile unsigned int *) 0x5c)	   		/* DMA13 General purpose			      			*/
#define pEI13   ((volatile unsigned int *) 0x5d)	   		/* External DMA13 address			      			*/
#define pEM13   ((volatile unsigned int *) 0x5e)	   		/* External DMA13 address modifier		      		*/
#define pEC13   ((volatile unsigned int *) 0x5f)	   		/* External DMA13 counter			      			*/

#define pII0    ((volatile unsigned int *) 0x60)	   		/* Internal DMA0 memory address		      			*/
#define pIM0    ((volatile unsigned int *) 0x61)	   		/* Internal DMA0 memory access modifier	      		*/
#define pC0     ((volatile unsigned int *) 0x62)	   		/* Contains number of DMA0 transfers remainnig     	*/
#define pCP0    ((volatile unsigned int *) 0x63)	   		/* Points to next DMA0 parameters		      		*/
#define pGP0    ((volatile unsigned int *) 0x64)	   		/* DMA0 General purpose / 2-D DMA		      		*/
#define pDB0    ((volatile unsigned int *) 0x65)	   		/* DMA0 General purpose / 2-D DMA		      		*/
#define pDA0    ((volatile unsigned int *) 0x66)	   		/* DMA0 General purpose / 2-D DMA		      		*/

#define pII1    ((volatile unsigned int *) 0x68)	   		/* Internal DMA1 memory address		      			*/
#define pIM1    ((volatile unsigned int *) 0x69)	   		/* Internal DMA1 memory access modifier	      		*/
#define pC1     ((volatile unsigned int *) 0x6a)	   		/* Contains number of DMA1 transfers remainnig     	*/
#define pCP1    ((volatile unsigned int *) 0x6b)	   		/* Points to next DMA1 parameters		      		*/
#define pGP1    ((volatile unsigned int *) 0x6c)	   		/* DMA1 General purpose / 2-D DMA		      		*/
#define pDB1    ((volatile unsigned int *) 0x6d)	   		/* DMA1 General purpose / 2-D DMA		      		*/
#define pDA1    ((volatile unsigned int *) 0x6e)	   		/* DMA1 General purpose / 2-D DMA		      		*/

#define pII2    ((volatile unsigned int *) 0x70)	   		/* Internal DMA2 memory address		      			*/
#define pIM2    ((volatile unsigned int *) 0x71)	   		/* Internal DMA2 memory access modifier	      		*/
#define pC2     ((volatile unsigned int *) 0x72)	   		/* Contains number of DMA2 transfers remainnig     	*/
#define pCP2    ((volatile unsigned int *) 0x73)	   		/* Points to next DMA2 parameters		      		*/
#define pGP2    ((volatile unsigned int *) 0x74)	   		/* DMA2 General purpose / 2-D DMA		      		*/
#define pDB2    ((volatile unsigned int *) 0x75)	   		/* DMA2 General purpose / 2-D DMA		      		*/
#define pDA2    ((volatile unsigned int *) 0x76)	   		/* DMA2 General purpose / 2-D DMA		      		*/

#define pII3    ((volatile unsigned int *) 0x78)	   		/* Internal DMA3 memory address		      			*/
#define pIM3    ((volatile unsigned int *) 0x79)	   		/* Internal DMA3 memory access modifier	      		*/
#define pC3     ((volatile unsigned int *) 0x7a)	   		/* Contains number of DMA3 transfers remainnig     	*/
#define pCP3    ((volatile unsigned int *) 0x7b)	   		/* Points to next DMA3 parameters		      		*/
#define pGP3    ((volatile unsigned int *) 0x7c)	   		/* DMA3 General purpose / 2-D DMA		      		*/
#define pDB3    ((volatile unsigned int *) 0x7d)	   		/* DMA3 General purpose / 2-D DMA		      		*/
#define pDA3    ((volatile unsigned int *) 0x7e)	   		/* DMA3 General purpose / 2-D DMA		      		*/

#define pII6    ((volatile unsigned int *) 0x80)	   		/* Internal DMA6 memory address		      			*/
#define pIM6    ((volatile unsigned int *) 0x81)	   		/* Internal DMA6 memory access modifier	      		*/
#define pC6     ((volatile unsigned int *) 0x82)	  		/* Contains number of DMA6 transfers remainnig     	*/
#define pCP6    ((volatile unsigned int *) 0x83)	   		/* Points to next DMA6 parameters		      		*/
#define pGP6    ((volatile unsigned int *) 0x84)	   		/* DMA6 General purpose / 2-D DMA		      		*/
#define pDB6    ((volatile unsigned int *) 0x85)	   		/* DMA6 General purpose / 2-D DMA		      		*/
#define pDA6    ((volatile unsigned int *) 0x86)	   		/* DMA6 General purpose / 2-D DMA		      		*/

#define pII7    ((volatile unsigned int *) 0x88)	   		/* Internal DMA7 memory address		      			*/
#define pIM7    ((volatile unsigned int *) 0x89)	   		/* Internal DMA7 memory access modifier	      		*/
#define pC7     ((volatile unsigned int *) 0x8a)	   		/* Contains number of DMA7 transfers remainnig     	*/
#define pCP7    ((volatile unsigned int *) 0x8b)	   		/* Points to next DMA7 parameters		      		*/
#define pGP7    ((volatile unsigned int *) 0x8c)	   		/* DMA7 General purpose / 2-D DMA		      		*/
#define pDB7    ((volatile unsigned int *) 0x8d)	   		/* DMA7 General purpose / 2-D DMA		      		*/
#define pDA7    ((volatile unsigned int *) 0x8e)	   		/* DMA7 General purpose / 2-D DMA		      		*/

#define pII8    ((volatile unsigned int *) 0x90)	   		/* Internal DMA8 memory address		      			*/
#define pIM8    ((volatile unsigned int *) 0x91)	   		/* Internal DMA8 memory access modifier	      		*/
#define pC8     ((volatile unsigned int *) 0x92)	   		/* Contains number of DMA8 transfers remainnig     	*/
#define pCP8    ((volatile unsigned int *) 0x93)	   		/* Points to next DMA8 parameters		      		*/
#define pGP8    ((volatile unsigned int *) 0x94)	   		/* DMA8 General purpose / 2-D DMA		      		*/
#define pDB8    ((volatile unsigned int *) 0x95)	   		/* DMA8 General purpose / 2-D DMA		      		*/
#define pDA8    ((volatile unsigned int *) 0x96)	   		/* DMA8 General purpose / 2-D DMA		      		*/

#define pII9    ((volatile unsigned int *) 0x98)	   		/* Internal DMA9 memory address		      			*/
#define pIM9    ((volatile unsigned int *) 0x99)	   		/* Internal DMA9 memory access modifier	      		*/
#define pC9     ((volatile unsigned int *) 0x9a)	   		/* Contains number of DMA9 transfers remainnig     	*/
#define pCP9    ((volatile unsigned int *) 0x9b)	   		/* Points to next DMA9 parameters		      		*/
#define pGP9    ((volatile unsigned int *) 0x9c)	   		/* DMA9 General purpose / 2-D DMA		      		*/
#define pDB9    ((volatile unsigned int *) 0x9d)	   		/* DMA9 General purpose / 2-D DMA		      		*/
#define pDA9    ((volatile unsigned int *) 0x9e)	   		/* DMA9 General purpose / 2-D DMA		      		*/

/* Emulation/Breakpoint Registers (remapped from UREG space) 					*/
/*  NOTES: 
       - These registers are ONLY accessible by the core 
       - It is *highly* recommended that these facilities be accessed only
         through the ADI emulator routines
*/   
/* Core Emulation HWBD Registers */
#define pPSA1S  ((volatile unsigned int *) 0xa0) /* Instruction address start #1                    	*/
#define pPSA1E  ((volatile unsigned int *) 0xa1) /* Instruction address end   #1                    	*/
#define pPSA2S  ((volatile unsigned int *) 0xa2) /* Instruction address start #2                    	*/
#define pPSA2E  ((volatile unsigned int *) 0xa3) /* Instruction address end   #2                    	*/
#define pPSA3S  ((volatile unsigned int *) 0xa4) /* Instruction address start #3                    	*/
#define pPSA3E  ((volatile unsigned int *) 0xa5) /* Instruction address end   #3                    	*/
#define pPSA4S  ((volatile unsigned int *) 0xa6) /* Instruction address start #4                    	*/
#define pPSA4E  ((volatile unsigned int *) 0xa7) /* Instruction address end   #4                    	*/
#define pPMDAS  ((volatile unsigned int *) 0xa8) /* Program Data address start                      	*/ 
#define pPMDAE  ((volatile unsigned int *) 0xa9) /* Program Data address end                        	*/
#define pDMA1S  ((volatile unsigned int *) 0xaa) /* Data address start #1                           	*/ 
#define pDMA1E  ((volatile unsigned int *) 0xab) /* Data address end   #1                           	*/  
#define pDMA2S  ((volatile unsigned int *) 0xac) /* Data address start #2                           	*/ 
#define pDMA2E  ((volatile unsigned int *) 0xad) /* Data address end   #2                           	*/ 
#define pEMUN   ((volatile unsigned int *) 0xae) /* hwbp hit-count register                         	*/

/* IOP Emulation HWBP Bounds Registers */
#define pIOAS	((volatile unsigned int *) 0xb0)		/* IOA Upper Bounds Register                       	*/
#define pIOAE	((volatile unsigned int *) 0xb1)		/* IOA Lower Bounds Register                       	*/
#define pEPAS	((volatile unsigned int *) 0xb2)		/* EPA Upper Bounds Register                       	*/
#define pEPAE	((volatile unsigned int *) 0xb3)		/* EPA Lower Bounds Register                       	*/

#define pLBUF0  ((volatile unsigned int *) 0xc0)			/* Link buffer 0				      				*/
#define pLBUF1  ((volatile unsigned int *) 0xc2)	   		/* Link buffer 1				      				*/
#define pLBUF2  ((volatile unsigned int *) 0xc4)	   		/* Link buffer 2				      				*/
#define pLBUF3  ((volatile unsigned int *) 0xc6)	   		/* Link buffer 3				      				*/
#define pLBUF4  ((volatile unsigned int *) 0xc8)	   		/* Link buffer 4				      				*/
#define pLBUF5  ((volatile unsigned int *) 0xca)	   		/* Link buffer 5				      				*/
#define pLCTL0  ((volatile unsigned int *) 0xcc)	   		/* Link buffer control			      				*/
#define pLCTL1  ((volatile unsigned int *) 0xcd)	   		/* Link buffer control			      				*/
#define pLCOM   ((volatile unsigned int *) 0xce)	   		/* Link common control			      				*/
#define pLAR    ((volatile unsigned int *) 0xcf)	   		/* Link assignment register			      			*/
#define pLSRQ   ((volatile unsigned int *) 0xd0)	   		/* Link service request and mask register	      	*/
#define pLPATH1 ((volatile unsigned int *) 0xd1)	   		/* Link path register 1			      				*/
#define pLPATH2 ((volatile unsigned int *) 0xd2)	   		/* Link path register 2			      				*/
#define pLPATH3 ((volatile unsigned int *) 0xd3)	   		/* Link path register 3			      				*/
#define pLPCNT  ((volatile unsigned int *) 0xd4)	   		/* Link path counter				      			*/
#define pCNST1  ((volatile unsigned int *) 0xd5)	   		/* Link port constant 1 register		      		*/
#define pCNST2  ((volatile unsigned int *) 0xd6)	   		/* Link port constant 2 register		      		*/

#define pSTCTL0	((volatile unsigned int *) 0xe0) /* Serial Port 0 Transmit Control Register          	*/ 
#define pSRCTL0	((volatile unsigned int *) 0xe1) /* Serial Port 0 Receive  Control Register           */ 
#define pTX0   	((volatile unsigned int *) 0xe2) /* Serial Port 0 Transmit Data Buffer                */ 
#define pRX0   	((volatile unsigned int *) 0xe3) /* Serial Port 0 Receive Data Buffer                 */ 
#define pTDIV0 	((volatile unsigned int *) 0xe4) /* Serial Port 0 Transmit Divisor                    */ 
#define pTCNT0 	((volatile unsigned int *) 0xe5) /* Serial Port 0 Transmit Count Reg                  */ 
#define pRDIV0 	((volatile unsigned int *) 0xe6) /* Serial Port 0 Receive Divisor                     */ 
#define pRCNT0 	((volatile unsigned int *) 0xe7) /* Serial Port 0 Receive Count Reg                   */ 
#define pMTCS0 	((volatile unsigned int *) 0xe8) /* Serial Port 0 Mulitchannel Transmit Selector      */ 
#define pMRCS0 	((volatile unsigned int *) 0xe9) /* Serial Port 0 Mulitchannel Receive Selector       */ 
#define pMTCCS0	((volatile unsigned int *) 0xea) /* Serial Port 0 Mulitchannel Transmit Selector      */ 
#define pMRCCS0	((volatile unsigned int *) 0xeb) /* Serial Port 0 Mulitchannel Receive Selector       */ 
#define pKEYWD0  ((volatile unsigned int *) 0xec) /* Serial Port 0 Receive Comparison Register         */
#define pKEYMASK0 ((volatile unsigned int *) 0xed) /* Serial Port 0 Receive Comparison Mask Register    */
#define pSPATH0	((volatile unsigned int *) 0xee) /* Serial Port 0 Path Length (Mesh Multiprocessing)  */
#define pSPCNT0	((volatile unsigned int *) 0xef) /* Serial Port 0 Path Counter (Mesh Multiprocessing) */

#define pSTCTL1	((volatile unsigned int *) 0xf0) /* Serial Port 1 Transmit Control Register           */
#define pSRCTL1	((volatile unsigned int *) 0xf1) /* Serial Port 1 Receive  Control Register           */
#define pTX1   	((volatile unsigned int *) 0xf2) /* Serial Port 1 Transmit Data Buffer                */
#define pRX1   	((volatile unsigned int *) 0xf3) /* Serial Port 1 Receive Data Buffer                 */
#define pTDIV1 	((volatile unsigned int *) 0xf4) /* Serial Port 1 Transmit Divisor                    */
#define pTCNT1 	((volatile unsigned int *) 0xf5) /* Serial Port 1 Transmit Count Reg                  */
#define pRDIV1 	((volatile unsigned int *) 0xf6) /* Serial Port 1 Receive Divisor                     */
#define pRCNT1 	((volatile unsigned int *) 0xf7) /* Serial Port 1 Receive Count Reg                   */
#define pMTCS1 	((volatile unsigned int *) 0xf8) /* Serial Port 1 Mulitchannel Transmit Selector      */
#define pMRCS1 	((volatile unsigned int *) 0xf9) /* Serial Port 1 Mulitchannel Receive Selector       */
#define pMTCCS1	((volatile unsigned int *) 0xfa) /* Serial Port 1 Mulitchannel Transmit Selector      */
#define pMRCCS1	((volatile unsigned int *) 0xfb) /* Serial Port 1 Mulitchannel Receive Selector       */
#define pKEYWD1  ((volatile unsigned int *) 0xfc) /* Serial Port 1 Receive Comparison Register         */
#define pKEYMASK1 ((volatile unsigned int *) 0xfd) /* Serial Port 1 Receive Comparison Mask Register    */
#define pSPATH1	((volatile unsigned int *) 0xfe) /* Serial Port 1 Path Length (Mesh Multiprocessing)  */
#define pSPCNT1	((volatile unsigned int *) 0xff) /* Serial Port 1 Path Counter (Mesh Multiprocessing) */

#endif /* __CDEF21160_H_ */


