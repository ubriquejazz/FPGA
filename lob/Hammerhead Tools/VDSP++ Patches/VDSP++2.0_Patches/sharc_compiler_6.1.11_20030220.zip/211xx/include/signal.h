/************************************************************************
 *
 * signal.h
 *
 * (c) Copyright 2001 Analog Devices, Inc.  All rights reserved.
 *
 ************************************************************************/

/* signal.h - $Date: 2002/05/02 15:37:49 $ */

#ifndef __SIGNAL_DEFINED
#define __SIGNAL_DEFINED


#if defined (__2116x__)
/* WARNING! IIOPAI will be deprecated in
 * a future release. Use IICDI instead.
 */
#define SIG_IIOPAI (2)	
#define SIG_IICDI (2)

#endif

#define SIG_SOVF 	3	/* Available to either 020 or 060 */
#define SIG_TMZ0 	4

#define	SIG_IRQ2	6
#define	SIG_IRQ1	7
#define	SIG_IRQ0	8

#if defined(__ADSP21060__) || defined(__ADSP21061__) || defined(__ADSP21062__) || defined(__ADSP21065L__) || defined(__2116x__)

#define SIG_VIRPTI      5

#if defined(__ADSP21161__)
# define SIG_SP0I       10
# define SIG_SP1I       11
# define SIG_SP2I       12
# define SIG_SP3I       13
#else
# define SIG_SPR0I       10
# define SIG_SPR1I       11
# define SIG_SPT0I       12
# define SIG_SPT1I       13
#endif

#if !(defined (__2116x__))

#if !defined(__ADSP21061__) && !defined(__ADSP21065L__)
#define SIG_LP2I        14
#define SIG_LP3I        15
#endif

#define SIG_EP0I        16
#define SIG_EP1I        17

#if !defined(__ADSP21061__) && !defined(__ADSP21065L__)
#define SIG_EP2I        18
#define SIG_EP3I        19
#define SIG_LSRQ        20
#endif

#define SIG_CB7		21
#define SIG_CB15	22
#define SIG_TMZ		23
#define SIG_FIX		24
#define SIG_FLTO	25
#define SIG_FLTU	26
#define SIG_FLTI	27
#define SIG_USR0	28
#define SIG_USR1	29
#define SIG_USR2	30
#define SIG_USR3	31

#else

#if !(defined(__ADSP21161__))
# define SIG_LP0I        14
# define SIG_LP1I        15
# define SIG_LP2I        16
# define SIG_LP3I        17
# define SIG_LP4I        18
# define SIG_LP5I        19
# define SIG_EP0I        20
# define SIG_EP1I        21
# define SIG_EP2I        22
# define SIG_EP3I        23
# define SIG_LSRQ        24
# define SIG_CB7	25
# define SIG_CB15	26
# define SIG_TMZ	27
# define SIG_FIX	28
# define SIG_FLTO	29
# define SIG_FLTU	30
# define SIG_FLTI	31
# define SIG_USR0	32
# define SIG_USR1	33
# define SIG_USR2	34
# define SIG_USR3	35
#else
# define SIG_LP0I        14
# define SIG_LP1I        15
# define SIG_SPIRI       16
# define SIG_SPITI       17
# define SIG_EP0I        18
# define SIG_EP1I        19
# define SIG_EP2I        20
# define SIG_EP3I        21
# define SIG_LSRQ        22
# define SIG_CB7	23
# define SIG_CB15	24
# define SIG_TMZ	25
# define SIG_FIX	26
# define SIG_FLTO	27
# define SIG_FLTU	28
# define SIG_FLTI	29
# define SIG_USR0	30
# define SIG_USR1	31
# define SIG_USR2	32
# define SIG_USR3	33
#endif
#endif



#elif defined(__ADSP21020__)

#define	SIG_IRQ3	5

#define SIG_CB7		11
#define SIG_CB15	12
#define SIG_TMZ		14
#define SIG_FIX		15
#define SIG_FLTO	16
#define SIG_FLTU	17
#define SIG_FLTI	18
#define SIG_USR0	24
#define SIG_USR1	25
#define SIG_USR2	26
#define SIG_USR3	27
#define SIG_USR4	28
#define SIG_USR5	29
#define SIG_USR6	30
#define SIG_USR7	31
#endif

#if defined(__2116x__)
# if defined (__ADSP21160__)
#  define ___SIG_LAST_HARDWARE_INT 35
#  define ___SIG_FIRST_INTERRUPT 2
# else
#  define ___SIG_LAST_HARDWARE_INT 33
#  define ___SIG_FIRST_INTERRUPT 2
# endif
#else
#define ___SIG_LAST_HARDWARE_INT 31
#define ___SIG_FIRST_INTERRUPT 3
#endif

#define ___SIG_LAST_INTERRUPT ___SIG_LAST_HARDWARE_INT+7

#define SIGABRT (___SIG_LAST_HARDWARE_INT+1)
#define	SIGILL	(___SIG_LAST_HARDWARE_INT+2)
#define SIGINT  (___SIG_LAST_HARDWARE_INT+3)
#define	SIGSEGV	(___SIG_LAST_HARDWARE_INT+4)
#define	SIGTERM	(___SIG_LAST_HARDWARE_INT+5)
#define SIGALRM (___SIG_LAST_HARDWARE_INT+6)		/* Software signal raised by timer */
#define SIGFPE  (___SIG_LAST_HARDWARE_INT+7)



#define SIG_DFL ((void (*)(int))0x01)
#define SIG_ERR ((void (*)(int))0x02)
#define SIG_IGN ((void (*)(int))0x03)

#if defined(__GNUC__) || defined(__ECC__)
/* Hide these definitions from assembly-language users in runtime support */

typedef int sig_atomic_t;

#if defined(__cplusplus)
extern "C" {
#endif

void (*signal(int _sig, void (*func)(int))) (int);
void (*signalf(int _sig, void (*func)(int))) (int);
void (*signals(int _sig, void (*func)(int))) (int);
void (*signalcb(int _sig, void (*func)(int))) (int);
void (*signalss(int _sig, void (*func)(int))) (int);

void (*signalnsm(int _sig, void (*func)(int))) (int);
void (*signalfnsm(int _sig, void (*func)(int))) (int);
void (*signalsnsm(int _sig, void (*func)(int))) (int);
void (*signalcbnsm(int _sig, void (*func)(int))) (int);
void (*signalssnsm(int _sig, void (*func)(int))) (int);

void (*interrupt(int _sig, void (*func)(int))) (int);
void (*interruptf(int _sig, void (*func)(int))) (int);
void (*interrupts(int _sig, void (*func)(int))) (int);
void (*interruptcb(int _sig, void (*func)(int))) (int);
void (*interruptss(int _sig, void (*func)(int))) (int);

void (*interruptnsm(int _sig, void (*func)(int))) (int);
void (*interruptfnsm(int _sig, void (*func)(int))) (int);
void (*interruptsnsm(int _sig, void (*func)(int))) (int);
void (*interruptcbnsm(int _sig, void (*func)(int))) (int);
void (*interruptssnsm(int _sig, void (*func)(int))) (int);

int raise(int);
int raisensm(int);

int clear_interrupt(int _sig);

#if defined(__cplusplus)
}
#endif

#endif

#endif
