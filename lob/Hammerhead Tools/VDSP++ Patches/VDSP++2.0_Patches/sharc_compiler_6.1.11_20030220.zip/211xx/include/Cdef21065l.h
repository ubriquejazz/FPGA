/************************************************************************
 *
 * Cdef21065l.h
 *
 * (c) Copyright 2001 Analog Devices, Inc.  All rights reserved.
 *
 ************************************************************************/

/* -----------------------------------------------------------------------------
Cdef21065L.h - SYSTEM AND IOP REGISTER BIT AND ADDRESS DEFINITIONS FOR ADSP-21065L
	
Last Modification on: $Date: 2002/03/14 12:18:24 $

This include file contains macros definitions of the IOP registers which
allow them to be used in C or C++ programs. Each macro is similar to that
in def21065l.h, except that the macro is prefixed with 'p' and the relevant
casts are include in the macro definition. They can be used as follows:

   *pSYSTAT = 0x12345678;  // Set the SYSTAT register

------------------------------------------------------------------------------*/

/* SYSCON Register */
#define pSYSCON ((volatile unsigned int *) 0x00) /* Memory mapped System Configuration Register     */

/* SYSTAT Register */
#define pSYSTAT ((volatile unsigned int *) 0x03) /* Memory mapped System Status Register	      */

/*------------------------  SYSTEM registers  -------------------------------------*/

#define pVIRPT		((volatile unsigned int *) 0x01)
#define pWAIT			((volatile unsigned int *) 0x02)

/*-------------------------  DMA BUFFER registers --------------------------*/

/* These are old register names  */

#define pDMAB0		((volatile unsigned int *) 0x04)
#define pDMAB1		((volatile unsigned int *) 0x05)

/* These are the new register names  */

#define pEPB0		((volatile unsigned int *) 0x04)
#define pEPB1		((volatile unsigned int *) 0x05)

/*-------------------------  MESSAGE registers  ----------------------------*/

#define pMSGR_0		((volatile unsigned int *) 0x08)
#define pMSGR_1		((volatile unsigned int *) 0x09)
#define pMSGR_2		((volatile unsigned int *) 0x0a)
#define pMSGR_3		((volatile unsigned int *) 0x0b)
#define pMSGR_4		((volatile unsigned int *) 0x0c)
#define pMSGR_5		((volatile unsigned int *) 0x0d)
#define pMSGR_6		((volatile unsigned int *) 0x0e)
#define pMSGR_7		((volatile unsigned int *) 0x0f)

/* Real names for these registers don't have an underscore;    */
/* The previous definition left in for legacy.  Future designs */
/* should use the names below.                                 */

#define pMSGR0		((volatile unsigned int *) 0x08)
#define pMSGR1		((volatile unsigned int *) 0x09)
#define pMSGR2		((volatile unsigned int *) 0x0a)
#define pMSGR3		((volatile unsigned int *) 0x0b)
#define pMSGR4		((volatile unsigned int *) 0x0c)
#define pMSGR5		((volatile unsigned int *) 0x0d)
#define pMSGR6		((volatile unsigned int *) 0x0e)
#define pMSGR7		((volatile unsigned int *) 0x0f)

/*---------------------  MISCELLANEOUS registers  ------------------------*/

#define pBMAX			((volatile unsigned int *) 0x18)
#define pBCNT			((volatile unsigned int *) 0x19)
#define pELAST		((volatile unsigned int *) 0x1b)

/*---------------------  DMAC registers  ---------------------------------*/

/* These are the old register names  */

#define pDMAC6		((volatile unsigned int *) 0x1c)
#define pDMAC7		((volatile unsigned int *) 0x1d)

/* These are the new register names  */

#define pDMAC0		((volatile unsigned int *) 0x1c)
#define pDMAC1		((volatile unsigned int *) 0x1d)

/*--------------------------- 21065L registers  --------------------------*/

#define pSDRDIV          ((volatile unsigned int *) 0x20)
#define pSDRCNT          ((volatile unsigned int *) 0x21)
#define pSDADDLAT        ((volatile unsigned int *) 0x22)

#define pTPERIOD0        ((volatile unsigned int *) 0x28)
#define pTPWIDTH0        ((volatile unsigned int *) 0x29)
#define pTCOUNT0         ((volatile unsigned int *) 0x2a)
#define pTPERIOD1        ((volatile unsigned int *) 0x2b)
#define pTPWIDTH1        ((volatile unsigned int *) 0x2c)
#define pTCOUNT1         ((volatile unsigned int *) 0x2d)
#define pIOCTL           ((volatile unsigned int *) 0x2e)
#define pIOSTAT          ((volatile unsigned int *) 0x2f)

/*---------------------  DMA ADDRESS registers **** NEW Names **** ---------*/

#define pDMASTAT    ((volatile unsigned int *) 0x37) /* DMA channel status reg.              */

#define pIIR0A      ((volatile unsigned int *) 0x60) /* DMA channel 0 index reg.            */
#define pIMR0A      ((volatile unsigned int *) 0x61) /* DMA channel 0 modify reg.           */
#define pCR0A       ((volatile unsigned int *) 0x62) /* DMA channel 0 count reg.            */
#define pCPR0A      ((volatile unsigned int *) 0x63) /* DMA channel 0 chain pointer reg.    */
#define pGPR0A      ((volatile unsigned int *) 0x64) /* DMA channel 0 general purpose reg.  */

#define pIIR0B      ((volatile unsigned int *) 0x30) /* DMA channel 1 index reg.            */
#define pIMR0B      ((volatile unsigned int *) 0x31) /* DMA channel 1 modify                */
#define pCR0B       ((volatile unsigned int *) 0x32) /* DMA channel 1 count reg.            */
#define pCPR0B      ((volatile unsigned int *) 0x33) /* DMA channel 1 chain pointer reg.    */
#define pGPR0B      ((volatile unsigned int *) 0x34) /* DMA channel 1 general purpose reg.  */

#define pIIR1A      ((volatile unsigned int *) 0x68) /* DMA channel 2 index reg.            */
#define pIMR1A      ((volatile unsigned int *) 0x69) /* DMA channel 2 modify                */
#define pCR1A       ((volatile unsigned int *) 0x6A) /* DMA channel 2 count reg.            */
#define pCPR1A      ((volatile unsigned int *) 0x6B) /* DMA channel 2 chain pointer reg.    */
#define pGPR1A      ((volatile unsigned int *) 0x6C) /* DMA channel 2 general purpose reg.  */

#define pIIR1B      ((volatile unsigned int *) 0x38) /* DMA channel 3 index reg.            */
#define pIMR1B      ((volatile unsigned int *) 0x39) /* DMA channel 3 modify                */
#define pCR1B       ((volatile unsigned int *) 0x3A) /* DMA channel 3 count reg.            */
#define pCPR1B      ((volatile unsigned int *) 0x3B) /* DMA channel 3 chain pointer reg.    */
#define pGPR1B      ((volatile unsigned int *) 0x3C) /* DMA channel 3 general purpose reg.  */

#define pIIT0A      ((volatile unsigned int *) 0x70) /* DMA channel 4 index reg.            */
#define pIMT0A      ((volatile unsigned int *) 0x71) /* DMA channel 4 modify                */
#define pCT0A       ((volatile unsigned int *) 0x72) /* DMA channel 4 count reg.            */
#define pCPT0A      ((volatile unsigned int *) 0x73) /* DMA channel 4 chain pointer reg.    */
#define pGPT0A      ((volatile unsigned int *) 0x74) /* DMA channel 4 general purpose reg.  */

#define pIIT0B      ((volatile unsigned int *) 0x50) /* DMA channel 5 index reg.            */
#define pIMT0B      ((volatile unsigned int *) 0x51) /* DMA channel 5 modify                */
#define pCT0B       ((volatile unsigned int *) 0x52) /* DMA channel 5 count reg.            */
#define pCPT0B      ((volatile unsigned int *) 0x53) /* DMA channel 5 chain pointer reg.    */
#define pGPT0B      ((volatile unsigned int *) 0x54) /* DMA channel 5 general purpose reg.  */

#define pIIT1A      ((volatile unsigned int *) 0x78) /* DMA channel 6 index reg.            */
#define pIMT1A      ((volatile unsigned int *) 0x79) /* DMA channel 6 modify                */
#define pCT1A       ((volatile unsigned int *) 0x7A) /* DMA channel 6 count reg.            */
#define pCPT1A      ((volatile unsigned int *) 0x7B) /* DMA channel 6 chain pointer reg.    */
#define pGPT1A      ((volatile unsigned int *) 0x7C) /* DMA channel 6 general purpose reg.  */

#define pIIT1B      ((volatile unsigned int *) 0x58) /* DMA channel 7 index reg.            */
#define pIMT1B      ((volatile unsigned int *) 0x59) /* DMA channel 7 modify                */
#define pCT1B       ((volatile unsigned int *) 0x5A) /* DMA channel 7 count reg.            */
#define pCPT1B      ((volatile unsigned int *) 0x5B) /* DMA channel 7 chain pointer reg.    */
#define pGPT1B      ((volatile unsigned int *) 0x5C) /* DMA channel 7 general purpose reg.  */

#define pIIEP0      ((volatile unsigned int *) 0x40) /* DMA channel 8 index reg.            */
#define pIMEP0      ((volatile unsigned int *) 0x41) /* DMA channel 8 modify                */
#define pCEP0       ((volatile unsigned int *) 0x42) /* DMA channel 8 count reg.            */
#define pCPEP0      ((volatile unsigned int *) 0x43) /* DMA channel 8 chain pointer reg.    */
#define pGPEP0      ((volatile unsigned int *) 0x44) /* DMA channel 8 general purpose reg.  */
#define pEIEP0      ((volatile unsigned int *) 0x45) /* DMA channel 8 external index reg.   */
#define pEMEP0      ((volatile unsigned int *) 0x46) /* DMA channel 8 external modify       */
#define pECEP0      ((volatile unsigned int *) 0x47) /* DMA channel 8 external count reg.   */

#define pIIEP1      ((volatile unsigned int *) 0x48) /* DMA channel 9 index reg.            */
#define pIMEP1      ((volatile unsigned int *) 0x49) /* DMA channel 9 modify                */
#define pCEP1       ((volatile unsigned int *) 0x4A) /* DMA channel 9 count reg.            */
#define pCPEP1      ((volatile unsigned int *) 0x4B) /* DMA channel 9 chain pointer reg.    */
#define pGPEP1      ((volatile unsigned int *) 0x4C) /* DMA channel 9 general purpose reg.  */
#define pEIEP1      ((volatile unsigned int *) 0x4D) /* DMA channel 9 external index reg.   */
#define pEMEP1      ((volatile unsigned int *) 0x4E) /* DMA channel 9 external modify       */
#define pECEP1      ((volatile unsigned int *) 0x4F) /* DMA channel 9 external count reg.   */


/*---------------------  DMA ADDRESS registers **** OLD Names **** ---------*/
/* DMA channel status reg. defined under NEW Names */

#define pII0      ((volatile unsigned int *) 0x60) /* DMA channel 0 index reg.            */
#define pIM0      ((volatile unsigned int *) 0x61) /* DMA channel 0 modify reg.           */
#define pC0       ((volatile unsigned int *) 0x62) /* DMA channel 0 count reg.            */
#define pCP0      ((volatile unsigned int *) 0x63) /* DMA channel 0 chain pointer reg.    */
#define pGP0      ((volatile unsigned int *) 0x64) /* DMA channel 0 general purpose reg.  */

#define pII1      ((volatile unsigned int *) 0x30) /* DMA channel 1 index reg.            */
#define pIM1      ((volatile unsigned int *) 0x31) /* DMA channel 1 modify                */
#define pC1       ((volatile unsigned int *) 0x32) /* DMA channel 1 count reg.            */
#define pCP1      ((volatile unsigned int *) 0x33) /* DMA channel 1 chain pointer reg.    */
#define pGP1      ((volatile unsigned int *) 0x34) /* DMA channel 1 general purpose reg.  */

#define pII2      ((volatile unsigned int *) 0x68) /* DMA channel 2 index reg.            */
#define pIM2      ((volatile unsigned int *) 0x69) /* DMA channel 2 modify                */
#define pC2       ((volatile unsigned int *) 0x6A) /* DMA channel 2 count reg.            */
#define pCP2      ((volatile unsigned int *) 0x6B) /* DMA channel 2 chain pointer reg.    */
#define pGP2      ((volatile unsigned int *) 0x6C) /* DMA channel 2 general purpose reg.  */

#define pII3      ((volatile unsigned int *) 0x38) /* DMA channel 3 index reg.            */
#define pIM3      ((volatile unsigned int *) 0x39) /* DMA channel 3 modify                */
#define pC3       ((volatile unsigned int *) 0x3A) /* DMA channel 3 count reg.            */
#define pCP3      ((volatile unsigned int *) 0x3B) /* DMA channel 3 chain pointer reg.    */
#define pGP3      ((volatile unsigned int *) 0x3C) /* DMA channel 3 general purpose reg.  */

#define pII4      ((volatile unsigned int *) 0x70) /* DMA channel 4 index reg.            */
#define pIM4      ((volatile unsigned int *) 0x71) /* DMA channel 4 modify                */
#define pC4       ((volatile unsigned int *) 0x72) /* DMA channel 4 count reg.            */
#define pCP4      ((volatile unsigned int *) 0x73) /* DMA channel 4 chain pointer reg.    */
#define pGP4      ((volatile unsigned int *) 0x74) /* DMA channel 4 general purpose reg.  */

#define pII5      ((volatile unsigned int *) 0x50) /* DMA channel 5 index reg.            */
#define pIM5      ((volatile unsigned int *) 0x51) /* DMA channel 5 modify                */
#define pC5       ((volatile unsigned int *) 0x52) /* DMA channel 5 count reg.            */
#define pCP5      ((volatile unsigned int *) 0x53) /* DMA channel 5 chain pointer reg.    */
#define pGP5      ((volatile unsigned int *) 0x54) /* DMA channel 5 general purpose reg.  */

#define pII6      ((volatile unsigned int *) 0x78) /* DMA channel 6 index reg.            */
#define pIM6      ((volatile unsigned int *) 0x79) /* DMA channel 6 modify                */
#define pC6       ((volatile unsigned int *) 0x7A) /* DMA channel 6 count reg.            */
#define pCP6      ((volatile unsigned int *) 0x7B) /* DMA channel 6 chain pointer reg.    */
#define pGP6      ((volatile unsigned int *) 0x7C) /* DMA channel 6 general purpose reg.  */

#define pII7      ((volatile unsigned int *) 0x58) /* DMA channel 7 index reg.            */
#define pIM7      ((volatile unsigned int *) 0x59) /* DMA channel 7 modify                */
#define pC7       ((volatile unsigned int *) 0x5A) /* DMA channel 7 count reg.            */
#define pCP7      ((volatile unsigned int *) 0x5B) /* DMA channel 7 chain pointer reg.    */
#define pGP7      ((volatile unsigned int *) 0x5C) /* DMA channel 7 general purpose reg.  */

#define pII8      ((volatile unsigned int *) 0x40) /* DMA channel 8 index reg.            */
#define pIM8      ((volatile unsigned int *) 0x41) /* DMA channel 8 modify                */
#define pC8       ((volatile unsigned int *) 0x42) /* DMA channel 8 count reg.            */
#define pCP8      ((volatile unsigned int *) 0x43) /* DMA channel 8 chain pointer reg.    */
#define pGP8      ((volatile unsigned int *) 0x44) /* DMA channel 8 general purpose reg.  */
#define pEI8      ((volatile unsigned int *) 0x45) /* DMA channel 8 external index reg.   */
#define pEM8      ((volatile unsigned int *) 0x46) /* DMA channel 8 external modify       */
#define pEC8      ((volatile unsigned int *) 0x47) /* DMA channel 8 external count reg.   */

#define pII9      ((volatile unsigned int *) 0x48) /* DMA channel 9 index reg.            */
#define pIM9      ((volatile unsigned int *) 0x49) /* DMA channel 9 modify                */
#define pC9       ((volatile unsigned int *) 0x4A) /* DMA channel 9 count reg.            */
#define pCP9      ((volatile unsigned int *) 0x4B) /* DMA channel 9 chain pointer reg.    */
#define pGP9      ((volatile unsigned int *) 0x4C) /* DMA channel 9 general purpose reg.  */
#define pEI9      ((volatile unsigned int *) 0x4D) /* DMA channel 9 external index reg.   */
#define pEM9      ((volatile unsigned int *) 0x4E) /* DMA channel 9 external modify       */
#define pEC9      ((volatile unsigned int *) 0x4F) /* DMA channel 9 external count reg.   */


/*-------------------  MSP BOUNDS CHECKING registers  ---------------------*/

#define pDMAUB		((volatile unsigned int *) 0xa0)
#define pDMALB		((volatile unsigned int *) 0xa1)
#define pPMAUB		((volatile unsigned int *) 0xa2)
#define pPMALB		((volatile unsigned int *) 0xa3)
#define pIOAUB		((volatile unsigned int *) 0xa4)
#define pIOALB		((volatile unsigned int *) 0xa5)
#define pEPAUB		((volatile unsigned int *) 0xa6)
#define pEPALB		((volatile unsigned int *) 0xa7)

/*---------------  Emulation BOUNDS CHECKING registers  -------------------*/

#define pIOAS		((volatile unsigned int *) 0xac)
#define pIOAE		((volatile unsigned int *) 0xad)
#define pEPAS		((volatile unsigned int *) 0xae)
#define pEPAE		((volatile unsigned int *) 0xaf)

/*---------------------  SPORT registers --------------------------------*/

#define pSTCTL0          ((volatile unsigned int *) 0xe0)
#define pSRCTL0          ((volatile unsigned int *) 0xe1)
#define pTX0             ((volatile unsigned int *) 0xe2)
#define pRX0             ((volatile unsigned int *) 0xe3)
#define pTDIV0           ((volatile unsigned int *) 0xe4)
#define pTCNT0           ((volatile unsigned int *) 0xe5)
#define pRDIV0           ((volatile unsigned int *) 0xe6)
#define pRCNT0           ((volatile unsigned int *) 0xe7)
#define pMTCS0           ((volatile unsigned int *) 0xe8)
#define pMRCS0           ((volatile unsigned int *) 0xe9)
#define pMTCCS0          ((volatile unsigned int *) 0xea)
#define pMRCCS0          ((volatile unsigned int *) 0xeb)
#define pKEYWD0          ((volatile unsigned int *) 0xec)
#define pIMASK0          ((volatile unsigned int *) 0xed)

#define pSTCTL1          ((volatile unsigned int *) 0xf0)
#define pSRCTL1          ((volatile unsigned int *) 0xf1)
#define pTX1             ((volatile unsigned int *) 0xf2)
#define pRX1             ((volatile unsigned int *) 0xf3)
#define pTDIV1           ((volatile unsigned int *) 0xf4)
#define pTCNT1           ((volatile unsigned int *) 0xf5)
#define pRDIV1           ((volatile unsigned int *) 0xf6)
#define pRCNT1           ((volatile unsigned int *) 0xf7)
#define pMTCS1           ((volatile unsigned int *) 0xf8)
#define pMRCS1           ((volatile unsigned int *) 0xf9)
#define pMTCCS1          ((volatile unsigned int *) 0xfa)
#define pMRCCS1          ((volatile unsigned int *) 0xfb)
#define pKEYWD1          ((volatile unsigned int *) 0xfc)
#define pIMASK1          ((volatile unsigned int *) 0xfd)


/* -----------  Aliases for TX and Rx ------------- */

#define pTX0_A           ((volatile unsigned int *) 0xe2)
#define pRX0_A           ((volatile unsigned int *) 0xe3)
#define pTX1_A           ((volatile unsigned int *) 0xf2)
#define pRX1_A           ((volatile unsigned int *) 0xf3)

/* ------------ New regs for 21065L ------------------ */

#define pTX0_B           ((volatile unsigned int *) 0xee)
#define pRX0_B           ((volatile unsigned int *) 0xef)
#define pTX1_B           ((volatile unsigned int *) 0xfe)
#define pRX1_B           ((volatile unsigned int *) 0xff)
