/************************************************************************
 *
 * math.h
 *
 * (c) Copyright 2001 Analog Devices, Inc.  All rights reserved.
 *
 ************************************************************************/

/* math.h - $Date: 2002/06/04 09:42:16 $ */

#ifndef __MATH_DEFINED
#define __MATH_DEFINED

#ifndef HUGE_VAL
#ifdef __DOUBLES_ARE_FLOATS__
#define HUGE_VAL    3.402823466e+38F
#else
#define HUGE_VAL    1.797693134862315708e+308
#endif
#endif

#ifndef __BP
#if defined(__NO_BUILTIN) || defined(__GNUC__)
#define __BP(x) x
#else
#define __BP(x) ()
#endif
#endif

#if !defined(__NO_BUILTIN) && !defined(__GNUC__)
#define fabsf	__builtin_fabsf
#define favgf	__builtin_favgf
#define fclipf	__builtin_fclipf
#define fmaxf	__builtin_fmaxf
#define fminf	__builtin_fminf
#define copysignf __builtin_copysignf
#define fsignf __builtin_fsignf

#if !defined(__cplusplus)
#define frexpf	__builtin_frexpf
#define modff	__builtin_modff

#ifndef __DOUBLES_ARE_FLOATS__
#define frexp	__builtin_frexp
#define modf	__builtin_modf
#endif
#endif /* __cplusplus */
#endif

/* ========== Double Precision Functions ========== */

#ifndef __DOUBLES_ARE_FLOATS__

#if defined(__cplusplus) 
extern "C" {
#endif

double	acos(double);
double	asin(double);
double	atan(double);
double	atan2(double, double);
double	cos(double);
double	sin(double);
double	tan(double);
double 	cot(double);
double	cosh(double);
double	sinh(double);
double	tanh(double);
double	exp(double);
double	ldexp(double, int);
double	log(double);
double	log10(double);

#if defined(__cplusplus) 
}
#endif

#if defined(__cplusplus) 

extern "C" {
double  frexp(double, int *);
double  __frexpP(double, int __pm *);

double  modf(double, double *);
double  modfP(double, double __pm *);
}

extern "C++" {

__inline double  frexp(double _a, int __pm * _b)
{
  return __frexpP(_a, _b);
}

__inline double  modf(double _a, double __pm * _b)
{
  return modfP(_a, _b);
}

}

#else /* __cplusplus */

double	frexp __BP((double, int *));
double	modf __BP((double, double *));

#endif /* __cplusplus */

#if defined(__cplusplus) 
extern "C" {
#endif

double	pow(double, double);
double	sqrt(double);
double	rsqrt(double);
double	ceil(double);
double	fabs(double);
double	floor(double);
double	fmod(double, double);
int	isnan(double);
int	isinf(double);

/* The following functions are currently supported only for floats. */

/* double favg(double, double); */
/* double fclip(double, double); */
/* double fmax(double, double); */
/* double fmin(double, double); */
/* double copysign(double, double); */
/* double fsign(double, double); */

#if defined(__cplusplus) 
}
#endif

#endif

/* ========== Single Precision Functions ========== */

#if defined(__cplusplus) 
extern "C" {
#endif

float	acosf(float);
float	asinf(float);
float	atanf(float);
float	atan2f(float, float);
float	cosf(float);
float	sinf(float);
float	tanf(float);
float   cotf(float);
float	coshf(float);
float	sinhf(float);
float	tanhf(float);
float	expf(float);
float	ldexpf(float, int);
float	logf(float);
float	log10f(float);

#if defined(__cplusplus) 
}
#endif

#if defined(__cplusplus) 
extern "C" {

float	frexpf(float, int *);
float	__frexpfP(float, int __pm *);

float	modff(float, float *);
float	__modffP(float, float __pm *);
}

extern "C++" {

__inline float frexpf(float _a, int __pm * _b)
{
  return __frexpfP(_a, _b);
}

__inline float modff(float _a, float __pm * _b)
{
  return  __modffP(_a, _b);
}

}

#else /* __cplusplus */

float	frexpf __BP((float, int *));
float	modff __BP((float, double *));

#endif /* __cplusplus */

#if defined(__cplusplus) 
extern "C" {
#endif

float	powf(float, float);
float	sqrtf(float);
float	rsqrtf(float);
float	ceilf(float);
float	fabsf(float);
float	floorf(float);
float	fmodf(float, float);
int	isnanf(float);
int	isinff(float);

/* The following functions are currently supported only as builtins. */

float	favgf(float, float);
float	fclipf(float, float);
float	fmaxf(float, float);
float	fminf(float, float);
float	copysignf(float, float);
float	fsignf(float, float);

#if defined(__cplusplus) 
}
#endif

/* ========== Double Precision Functions ========== */
/* ==========    when double == float    ========== */

#ifdef __DOUBLES_ARE_FLOATS__
#define acos	acosf
#define asin	asinf
#define atan	atanf
#define atan2	atan2f
#define cos	cosf
#define sin	sinf
#define tan	tanf
#define cot	cotf
#define cosh	coshf
#define sinh	sinhf
#define tanh	tanhf
#define exp	expf
#define frexp	frexpf
#define ldexp	ldexpf
#define log	logf
#define log10	log10f
#define modf	modff
#define pow	powf
#define sqrt	sqrtf
#define rsqrt	rsqrtf
#define ceil	ceilf
#define fabs	fabsf
#define floor	floorf
#define fmod	fmodf
#define isnan	isnanf
#define isinf	isinff
#define favg	favgf
#define fclip	fclipf
#define fmax	fmaxf
#define fmin	fminf
#define copysign copysignf
#define fsign fsignf
#endif

#endif
