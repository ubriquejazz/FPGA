/************************************************************************
 *
 * stdarg.h
 *
 * (c) Copyright 2001 Analog Devices, Inc.  All rights reserved.
 *
 ************************************************************************/

/* stdarg.h - $Date: 2001/10/19 10:55:46 $ */

#ifndef __STDARG_DEFINED
#define __STDARG_DEFINED

#if !defined(__VA_LIST_DEFINED) && !defined(_VA_LIST_DEFINED)
#define _VA_LIST_DEFINED
#define __VA_LIST_DEFINED
typedef char *va_list;
#endif

#define va_start(ap,v) \
        (void)((ap) = (va_list) __builtin_va_start(&(v), sizeof(v)))

#define va_arg(ap,t) (((t*)((ap) += sizeof(t)))[-1])

#define va_end(ap) (void)((ap) = 0)

#endif
