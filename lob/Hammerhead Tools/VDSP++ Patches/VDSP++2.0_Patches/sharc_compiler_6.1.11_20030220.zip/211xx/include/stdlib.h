/************************************************************************
 *
 * stdlib.h
 *
 * (c) Copyright 2001 Analog Devices, Inc.  All rights reserved.
 *
 ************************************************************************/

/* stdlib.h - $Date: 2002/07/12 11:37:43 $ */

#ifndef __STDLIB_DEFINED
#define __STDLIB_DEFINED

#ifndef NULL
# if defined(__cplusplus) 
#  define NULL	0
# else
#  define NULL	((void *)0)
# endif
#endif

#define EXIT_FAILURE 1
#define EXIT_SUCCESS 0
#define RAND_MAX 2147483647
#define MB_CUR_MAX 1

#ifndef __SIZE_T_DEFINED
#define __SIZE_T_DEFINED
typedef long unsigned int size_t;
#endif

#ifndef	__WCHAR_T_DEFINED
#define __WCHAR_T_DEFINED
typedef	int wchar_t;
#endif

typedef struct {int quot; int rem;} div_t;
typedef struct {long int quot; long int rem;} ldiv_t;


#if defined(__cplusplus) 

extern "C" {

int atoi(const char * _nptr);
int __atoiP(const char __pm * _nptr);

long atol(const char * _nptr);
long __atolP(const char __pm * _nptr);

long strtol(const char * _nptr, const char **__dm  _endptr, int _base);
long __strtolPP(const char __pm * _nptr, const char __pm ** _endptr, int _base);

unsigned long strtoul(const char *, const char **, int _base); 
unsigned long __strtoulPP(const char __pm * _nptr, const char __pm ** _endptr, int _base);

__inline unsigned long 
_c_library_strtoul(const char *_nptr, const char **_endptr, int _base)
{
    return strtoul(_nptr, _endptr, _base); 
}

__inline long _c_library_strtol(const char *_nptr, const char **_endptr, int _base)
{
    return strtol(_nptr, _endptr, _base); 
}

}

unsigned long strtoul(const char *, const char **, int _base); 

extern "C++" {

__inline int atoi(const char __pm * _nptr)
{
  return __atoiP(_nptr);
}
			/*******************/

__inline long atol(const char __pm * _nptr)
{
  return __atolP(_nptr);
}
			/*******************/

__inline long strtol(const char * _nptr, char ** _endptr, int _base)
{
  return _c_library_strtol(_nptr, (const char**)_endptr, _base);
}

__inline long strtol(const char __pm * _nptr, const char __pm ** _endptr, int _base)
{
  return __strtolPP(_nptr, _endptr, _base);
}

			/*******************/

__inline unsigned long 
strtoul(const char * _nptr, char ** _endptr, int _base)
{
  return _c_library_strtoul(_nptr, (const char**)_endptr, _base);
}

__inline unsigned long
strtoul(const char __pm * _nptr, const char __pm ** _endptr, int _base)
{
  return __strtoulPP(_nptr, _endptr, _base);
}
}
			/*******************/



extern "C" {

#ifndef __DOUBLES_ARE_FLOATS__

double atof(const char * _bptr);
double __atofP(const char __pm * _bptr);

double strtod(const char * _nptr, char ** _endptr);
double __strtodPP(const char __pm * _nptr, char __pm ** _endptr);

#else

#define atof atoff
#define strtod strtodf

float atoff(const char * _bptr);
float __atoffP(const char __pm * _bptr);

float strtodf(const char * _nptr, char ** _endptr);
float __strtodfPP(const char __pm * _nptr, char __pm ** _endptr);

#endif

}


extern "C++" {


#ifndef __DOUBLES_ARE_FLOATS__

__inline double atof(const char __pm * _bptr)
{
  return __atofP(_bptr);
}

__inline double strtod(const char __pm * _nptr, char __pm ** _endptr)
{
  return __strtodPP(_nptr, _endptr);
}

#else

__inline float atoff(const char __pm * _bptr)
{
  return __atoffP(_bptr);
}

__inline float strtodf(const char __pm * _nptr, char __pm ** _endptr)
{
  return __strtodfPP(_nptr, _endptr);
}

#endif

}


#else /* __cplusplus */



#ifndef __BP
#if defined(__NO_BUILTIN) || defined(__GNUC__)
#define __BP(x) x
#else
#define __BP(x) ()
#endif
#endif

#if !defined(__NO_BUILTIN) && !defined(__GNUC__)
#define atoi	__builtin_atoi
#define atol	__builtin_atol
#define strtol	__builtin_strtol
#define strtoul	__builtin_strtoul
#define atoff	__builtin_atoff
#define strtodf	__builtin_strtodf

#ifndef __DOUBLES_ARE_FLOATS__
#define atof	__builtin_atof
#define strtod	__builtin_strtod
#endif
#endif

int	atoi __BP((const char *_nptr));
long	atol __BP((const char *_nptr));
#ifndef __DOUBLES_ARE_FLOATS__
double	atof __BP((const char *_nptr));
double	strtod __BP((const char *_nptr, char **_endptr));
#else
#define atof atoff
#define strtod strtodf
#endif
float	atoff __BP((const char *_nptr));
float	strtodf __BP((const char *_nptr, char **_endptr));

long	strtol __BP((const char *_nptr, char **_endptr, int _base));
unsigned long strtoul __BP((const char *_nptr, char **_endptr, int _base));

#endif /* __cplusplus */

#if !defined(__NO_BUILTIN) && !defined(__GNUC__)
#define abs	__builtin_abs
#define labs	__builtin_labs

#define avg	__builtin_avg
#define clip	__builtin_clip
#define max	__builtin_max
#define min	__builtin_min
#define lavg	__builtin_lavg
#define lclip	__builtin_lclip
#define lmax	__builtin_lmax
#define lmin	__builtin_lmin

#endif

#if defined(__cplusplus) 
extern "C" {
#endif

int	rand(void);
void	srand(unsigned int _seed);
void *	calloc(size_t _nmemb, size_t _size);
void	free(void *_ptr);
void *	malloc(size_t _size);
void *	realloc(void *_prt, size_t _size);
int     set_alloc_type(char * _heap_name);
int	atexit(void (*func)(void));
char *	getenv(const char *_name);
int	system(const char *_string);
void *	bsearch(const void *_key, const void *_base, unsigned int _nelem,
		size_t _size, int (*_compare)(const void *, const void *));
void	qsort(void *_base, size_t _n, size_t _size,
	      int (*_compare)(const void *, const void *));

/* Analog extensions for heap management */
int   _heap_lookup_name(char * _heap_name);
void *_heap_calloc(int _heap_index, size_t _nmemb, size_t _size);
void  _heap_free(int _heap_index, void *_ptr);
void *_heap_malloc(int _heap_index, size_t _size);
void *_heap_realloc(int _heap_index, void *_prt, size_t _size);

#ifndef _ADI_THREADS
int   _heap_switch(int _heap_index);
int   set_alloc_type(char * _heap_name);
#endif

#ifndef __GNUC__
void	abort(void);
void	exit(int _status);
#endif

int	abs(int _j);
div_t	div(int _numer, int _denom);
long	labs(long _j);
ldiv_t	ldiv(long _numer, long _denom);

/* The following functions are currently supported only as builtins. */

int	avg(int _a, int _b);
int	clip(int _a, int _b);
int	max(int _a, int _b);
int	min(int _a, int _b);
long	lavg(long _a, long _b);
long	lclip(long _a, long _b);
long	lmax(long _a, long _b);
long	lmin(long _a, long _b);

#if defined(__cplusplus) 
}
#endif

#define heap_lookup_name  _heap_lookup_name
#define heap_calloc       _heap_calloc
#define heap_free         _heap_free
#define heap_malloc       _heap_malloc
#define heap_realloc      _heap_realloc

#ifndef _ADI_THREADS
#define heap_switch       _heap_switch
#endif

#endif  /* __STDLIB_DEFINED */
